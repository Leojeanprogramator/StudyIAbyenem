"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, BookOpen, Lightbulb, PenTool, Square, ArrowDown } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  isEssayRelated?: boolean
}

export function Chat() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [shouldStop, setShouldStop] = useState(false)
  const [autoScroll, setAutoScroll] = useState(true)
  const messagesContainerRef = useRef<HTMLDivElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const typingIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const abortControllerRef = useRef<AbortController | null>(null)

  const quickActions = [
    { label: "Explicar tópico", icon: BookOpen, prompt: "Explique um tópico específico do ENEM" },
    { label: "Dicas de estudo", icon: Lightbulb, prompt: "Me dê dicas de como estudar para" },
    { label: "Corrigir redação", icon: PenTool, prompt: "Quero que você corrija minha redação do ENEM" },
  ]

  const scrollToBottom = () => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight
    }
  }

  useEffect(() => {
    if (autoScroll) {
      scrollToBottom()
    }
  }, [messages, autoScroll])

  const handleScroll = () => {
    if (messagesContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current
      const isAtBottom = scrollHeight - scrollTop <= clientHeight + 50
      setAutoScroll(isAtBottom)
    }
  }

  useEffect(() => {
    const savedMessages = localStorage.getItem("chat-messages")
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages).map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        }))
        setMessages(parsedMessages)
      } catch (error) {
        console.error("Error loading chat history:", error)
      }
    }
  }, [])

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("chat-messages", JSON.stringify(messages))
    }
  }, [messages])

  const isEssayRelated = (content: string) => {
    const essayKeywords = [
      "redação",
      "redacao",
      "texto",
      "dissertação",
      "dissertacao",
      "argumentação",
      "argumentacao",
      "escrita",
      "escrever",
      "coesão",
      "coerência",
      "gramática",
      "gramatica",
      "competência",
      "competencia",
      "proposta de intervenção",
      "intervenção",
      "intervencao",
    ]
    return essayKeywords.some((keyword) => content.toLowerCase().includes(keyword))
  }

  const typeMessage = (content: string, callback: (message: Message) => void, isEssay = false) => {
    setIsTyping(true)
    setShouldStop(false)
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: "",
      role: "assistant",
      timestamp: new Date(),
      isEssayRelated: isEssay,
    }

    callback(assistantMessage)

    let currentIndex = 0
    const typingSpeed = 20

    typingIntervalRef.current = setInterval(() => {
      if (shouldStop) {
        if (typingIntervalRef.current) {
          clearInterval(typingIntervalRef.current)
          typingIntervalRef.current = null
        }
        setIsTyping(false)
        assistantMessage.content = content.substring(0, currentIndex) + (currentIndex < content.length ? "..." : "")
        setMessages((prev) => prev.map((msg) => (msg.id === assistantMessage.id ? { ...assistantMessage } : msg)))
        return
      }

      if (currentIndex >= content.length) {
        if (typingIntervalRef.current) {
          clearInterval(typingIntervalRef.current)
          typingIntervalRef.current = null
        }
        setIsTyping(false)
        return
      }

      assistantMessage.content = content.substring(0, currentIndex + 1)
      setMessages((prev) => prev.map((msg) => (msg.id === assistantMessage.id ? { ...assistantMessage } : msg)))
      currentIndex++
    }, typingSpeed)
  }

  const stopResponse = () => {
    setShouldStop(true)
    setIsLoading(false)

    // Stop typing immediately
    if (typingIntervalRef.current) {
      clearInterval(typingIntervalRef.current)
      typingIntervalRef.current = null
    }
    setIsTyping(false)

    // Abort API request immediately
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
    }
  }

  const sendMessage = async (content: string) => {
    if (!content.trim() || (isLoading && !shouldStop)) return

    if (isLoading || isTyping) {
      stopResponse()
      return
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)
    setShouldStop(false)

    const isEssay = isEssayRelated(content)

    try {
      abortControllerRef.current = new AbortController()

      const response = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: content,
          context: messages.slice(-8),
          mode: "chat",
        }),
        signal: abortControllerRef.current.signal,
      })

      if (!response.ok) throw new Error("Erro na resposta da API")

      const data = await response.json()

      typeMessage(
        data.response,
        (message) => {
          setMessages((prev) => [...prev, message])
        },
        isEssay,
      )
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        return
      }

      console.error("Erro ao enviar mensagem:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Desculpe, ocorreu um erro. Tente novamente em alguns instantes.",
        role: "assistant",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
      abortControllerRef.current = null
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(input)
  }

  const handleQuickAction = (prompt: string) => {
    setInput(prompt)
  }

  const shouldShowEssayPromotion = messages.some(
    (msg) => msg.role === "assistant" && msg.isEssayRelated && Date.now() - msg.timestamp.getTime() < 300000,
  )

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] max-h-[800px] min-h-[500px] bg-background border border-border rounded-lg overflow-hidden relative">
      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto px-4 py-6 scroll-smooth custom-scrollbar"
        onScroll={handleScroll}
      >
        <div className="max-w-4xl mx-auto">
          {messages.length === 0 ? (
            <motion.div
              className="text-center py-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="space-y-6">
                <motion.div
                  className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4"
                  animate={{
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  }}
                >
                  <BookOpen className="h-8 w-8 text-primary" />
                </motion.div>
                <motion.div
                  className="space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                >
                  <h3 className="text-xl font-semibold text-foreground">Olá! Sou seu professor particular de IA</h3>
                  <p className="text-base text-muted-foreground max-w-md mx-auto leading-relaxed">
                    Estou aqui para ajudar você a conquistar o ENEM. Como posso ajudar hoje?
                  </p>
                </motion.div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-lg mx-auto">
                  {quickActions.map((action, index) => {
                    const Icon = action.icon
                    return (
                      <motion.div
                        key={action.label}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 + index * 0.2, duration: 0.4 }}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Button
                          variant="outline"
                          className="flex items-center space-x-2 h-auto p-4 text-left bg-transparent hover-glow w-full"
                          onClick={() => handleQuickAction(action.prompt)}
                        >
                          <Icon className="h-5 w-5 text-primary flex-shrink-0" />
                          <span className="text-sm font-medium">{action.label}</span>
                        </Button>
                      </motion.div>
                    )
                  })}
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="space-y-6">
              <AnimatePresence>
                {messages.map((message, index) => (
                  <motion.div
                    key={message.id}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.95 }}
                    transition={{
                      duration: 0.4,
                      delay: index * 0.05,
                      type: "spring",
                      stiffness: 120,
                    }}
                    whileHover={{ scale: 1.01 }}
                  >
                    <div
                      className={`max-w-[85%] lg:max-w-[75%] rounded-2xl px-4 py-3 shadow-lg backdrop-blur-sm ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground ml-8 rounded-br-md"
                          : "bg-muted/80 text-foreground border border-border mr-8 rounded-bl-md"
                      }`}
                    >
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        <p className="text-sm leading-relaxed whitespace-pre-wrap break-words m-0">
                          {message.content}
                          {message.role === "assistant" &&
                            isTyping &&
                            message.id === messages[messages.length - 1]?.id && (
                              <motion.span
                                className="inline-block w-2 h-4 bg-primary ml-1 rounded-sm"
                                animate={{ opacity: [1, 0] }}
                                transition={{ duration: 0.6, repeat: Number.POSITIVE_INFINITY }}
                              />
                            )}
                        </p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <p className="text-xs opacity-70">
                          {message.timestamp.toLocaleTimeString("pt-BR", {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        {message.role === "assistant" && (
                          <Badge variant="secondary" className="text-xs px-2 py-0">
                            IA
                          </Badge>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              <AnimatePresence>
                {isLoading && (
                  <motion.div
                    className="flex justify-start"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="bg-muted/80 rounded-2xl px-4 py-3 flex items-center space-x-3 border border-border mr-8 shadow-md backdrop-blur-sm">
                      <div className="flex space-x-1">
                        {[0, 1, 2].map((i) => (
                          <motion.div
                            key={i}
                            className="w-2 h-2 bg-primary rounded-full"
                            animate={{ y: [0, -8, 0] }}
                            transition={{
                              duration: 0.6,
                              repeat: Number.POSITIVE_INFINITY,
                              delay: i * 0.2,
                            }}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">Pensando...</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Actions */}
      <AnimatePresence>
        {messages.length > 0 && (
          <motion.div
            className="px-4 py-3 border-t border-border bg-muted/20"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="max-w-4xl mx-auto">
              <div className="flex flex-wrap gap-2">
                {quickActions.map((action, index) => (
                  <motion.div
                    key={action.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.3 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Badge
                      variant="secondary"
                      className="cursor-pointer hover:bg-accent transition-all duration-200 hover-glow text-xs"
                      onClick={() => handleQuickAction(action.prompt)}
                    >
                      {action.label}
                    </Badge>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <motion.form
        onSubmit={handleSubmit}
        className="p-4 border-t border-border bg-background"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="max-w-4xl mx-auto">
          <div className="flex space-x-3">
            <motion.div className="flex-1" whileFocus={{ scale: 1.01 }} transition={{ duration: 0.2 }}>
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Digite sua pergunta ou dúvida..."
                disabled={isLoading && !isTyping}
                className="text-base hover-glow transition-all duration-300 rounded-xl border-border focus:border-primary focus:ring-2 focus:ring-primary/20 bg-muted/50"
              />
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                type="submit"
                disabled={!input.trim() && !isLoading && !isTyping}
                className="btn-animate px-4 rounded-xl"
                size="lg"
                onClick={(e) => {
                  if (isLoading || isTyping) {
                    e.preventDefault()
                    stopResponse()
                  }
                }}
              >
                {isLoading || isTyping ? <Square className="h-4 w-4" /> : <Send className="h-4 w-4" />}
              </Button>
            </motion.div>
          </div>
        </div>
      </motion.form>

      <AnimatePresence>
        {!autoScroll && messages.length > 0 && (
          <motion.div
            className="absolute bottom-20 right-8 z-10"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
          >
            <Button
              onClick={() => {
                scrollToBottom()
                setAutoScroll(true)
              }}
              size="sm"
              className="rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
              variant="secondary"
            >
              <ArrowDown className="h-4 w-4" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: hsl(var(--muted) / 0.3);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, hsl(var(--primary) / 0.8), hsl(var(--primary) / 0.6));
          border-radius: 10px;
          border: 1px solid hsl(var(--background));
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, hsl(var(--primary)), hsl(var(--primary) / 0.8));
          box-shadow: 0 2px 4px hsl(var(--primary) / 0.3);
        }
        .custom-scrollbar::-webkit-scrollbar-corner {
          background: transparent;
        }
        
        /* Firefox */
        .custom-scrollbar {
          scrollbar-width: thin;
          scrollbar-color: hsl(var(--primary) / 0.7) hsl(var(--muted) / 0.3);
        }
      `}</style>
    </div>
  )
}
