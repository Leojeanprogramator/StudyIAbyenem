"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Trophy, Target, BookOpen, PenTool, FileText, Flame } from "lucide-react"

export function PerfilDashboard() {
  // Mock data - em produção viria de uma API/banco de dados
  const userStats = {
    name: "Estudante ENEM",
    streak: 7,
    totalQuestions: 245,
    correctAnswers: 180,
    essaysAnalyzed: 12,
    simuladosCompleted: 8,
    studyHours: 45,
    level: "Intermediário",
  }

  const badges = [
    { name: "Primeira Redação", icon: PenTool, earned: true, description: "Analisou sua primeira redação" },
    { name: "5 Simulados", icon: FileText, earned: true, description: "Completou 5 simulados" },
    { name: "Streak 7 dias", icon: Flame, earned: true, description: "Estudou por 7 dias seguidos" },
    { name: "100 Questões", icon: BookOpen, earned: true, description: "Respondeu 100 questões" },
    { name: "Meta Mensal", icon: Target, earned: false, description: "Complete 20 simulados este mês" },
    { name: "Especialista", icon: Trophy, earned: false, description: "Alcance 90% de acertos" },
  ]

  const recentActivity = [
    { type: "simulado", subject: "Matemática", score: "8/10", date: "Hoje" },
    { type: "redacao", subject: "Redação", score: "780/1000", date: "Ontem" },
    { type: "questoes", subject: "Biologia", score: "15/20", date: "2 dias atrás" },
    { type: "simulado", subject: "Português", score: "9/10", date: "3 dias atrás" },
  ]

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "simulado":
        return FileText
      case "redacao":
        return PenTool
      case "questoes":
        return BookOpen
      default:
        return BookOpen
    }
  }

  const accuracy = Math.round((userStats.correctAnswers / userStats.totalQuestions) * 100)

  return (
    <div className="space-y-6">
      {/* User Info */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">{userStats.name}</CardTitle>
              <p className="text-muted-foreground">Nível {userStats.level}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Flame className="h-5 w-5 text-orange-500" />
              <span className="text-2xl font-bold text-orange-500">{userStats.streak}</span>
              <span className="text-sm text-muted-foreground">dias</span>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-primary">{userStats.totalQuestions}</div>
            <p className="text-sm text-muted-foreground">Questões respondidas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-500">{accuracy}%</div>
            <p className="text-sm text-muted-foreground">Taxa de acerto</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-blue-500">{userStats.essaysAnalyzed}</div>
            <p className="text-sm text-muted-foreground">Redações analisadas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-purple-500">{userStats.simuladosCompleted}</div>
            <p className="text-sm text-muted-foreground">Simulados completos</p>
          </CardContent>
        </Card>
      </div>

      {/* Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Progresso do Mês</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Meta de Questões (200)</span>
                <span>{userStats.totalQuestions}/200</span>
              </div>
              <Progress value={(userStats.totalQuestions / 200) * 100} />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Meta de Simulados (10)</span>
                <span>{userStats.simuladosCompleted}/10</span>
              </div>
              <Progress value={(userStats.simuladosCompleted / 10) * 100} />
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Horas de Estudo (60h)</span>
                <span>{userStats.studyHours}/60h</span>
              </div>
              <Progress value={(userStats.studyHours / 60) * 100} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badges */}
      <Card>
        <CardHeader>
          <CardTitle>Conquistas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {badges.map((badge) => {
              const Icon = badge.icon
              return (
                <div
                  key={badge.name}
                  className={`p-4 rounded-lg border text-center ${
                    badge.earned
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-muted text-muted-foreground"
                  }`}
                >
                  <Icon className={`h-8 w-8 mx-auto mb-2 ${badge.earned ? "text-primary" : "text-muted-foreground"}`} />
                  <h3 className="font-medium text-sm mb-1">{badge.name}</h3>
                  <p className="text-xs opacity-80">{badge.description}</p>
                  {badge.earned && <Badge className="mt-2 bg-primary text-primary-foreground">Conquistado</Badge>}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Atividade Recente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => {
              const Icon = getActivityIcon(activity.type)
              return (
                <div key={index} className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                  <Icon className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium text-sm">{activity.subject}</p>
                    <p className="text-xs text-muted-foreground">
                      {activity.type === "redacao"
                        ? "Redação analisada"
                        : activity.type === "simulado"
                          ? "Simulado completado"
                          : "Questões respondidas"}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">{activity.score}</p>
                    <p className="text-xs text-muted-foreground">{activity.date}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
