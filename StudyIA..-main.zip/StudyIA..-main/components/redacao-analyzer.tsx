"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Loader2,
  CheckCircle,
  AlertCircle,
  Lightbulb,
  Trophy,
  ExternalLink,
  BookOpen,
  Target,
  TrendingUp,
} from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion, AnimatePresence } from "framer-motion"

interface RedacaoResult {
  score: number
  comments: string
  competencies: {
    dominio_lingua: number
    compreensao_tema: number
    argumentacao: number
    coesao_coerencia: number
    proposta_intervencao: number
  }
  detailed_analysis?: {
    dominio_lingua: string
    compreensao_tema: string
    argumentacao: string
    coesao_coerencia: string
    proposta_intervencao: string
  }
  strengths: string[]
  weaknesses: string[]
  suggestions: string[]
  example_phrases: string[]
  grade_level?: string
  improvement_priority?: string
}

export function RedacaoAnalyzer() {
  const [text, setText] = useState("")
  const [result, setResult] = useState<RedacaoResult | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const wordCount = text
    .trim()
    .split(/\s+/)
    .filter((word) => word.length > 0).length

  const analyzeRedacao = async () => {
    if (!text.trim() || isLoading) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/ai/redacao", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      })

      if (!response.ok) throw new Error("Erro na análise")

      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error("Erro ao analisar redação:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 800) return "text-green-500"
    if (score >= 600) return "text-yellow-500"
    return "text-red-500"
  }

  const getGradeLevelColor = (level: string) => {
    switch (level) {
      case "Avançado":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "Intermediário":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Iniciante":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-blue-500/20 text-blue-400 border-blue-500/30"
    }
  }

  const competencyLabels = {
    dominio_lingua: "Domínio da Língua Portuguesa",
    compreensao_tema: "Compreensão do Tema",
    argumentacao: "Argumentação",
    coesao_coerencia: "Coesão e Coerência",
    proposta_intervencao: "Proposta de Intervenção",
  }

  return (
    <div className="space-y-6">
      {/* Header with new branding */}
      <motion.div
        className="text-center space-y-4"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <motion.div
          className="flex items-center justify-center space-x-3"
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          >
            <Trophy className="h-8 w-8 text-primary" />
          </motion.div>
          <h1 className="text-3xl md:text-4xl font-bold text-white">Nota Mil IA</h1>
        </motion.div>
        <motion.p
          className="text-muted-foreground max-w-2xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          Análise completa da sua redação com inteligência artificial avançada. Receba feedback detalhado e dicas para
          alcançar a nota 1000 no ENEM.
        </motion.p>
      </motion.div>

      {/* Editor */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
      >
        <Card className="hover-glow">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Escreva sua redação</span>
              <div className="flex items-center space-x-2">
                <motion.div animate={{ scale: wordCount > 0 ? [1, 1.1, 1] : 1 }} transition={{ duration: 0.3 }}>
                  <Badge variant="secondary" className="animate-pulse-slow">
                    {wordCount} palavras
                  </Badge>
                </motion.div>
                <motion.div
                  animate={{
                    scale: wordCount >= 250 && wordCount <= 400 ? [1, 1.05, 1] : 1,
                    color: wordCount >= 250 && wordCount <= 400 ? "#10b981" : "#6b7280",
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <Badge variant={wordCount >= 250 && wordCount <= 400 ? "default" : "outline"} className="text-xs">
                    {wordCount < 250 ? "Muito curta" : wordCount > 400 ? "Muito longa" : "Ideal"}
                  </Badge>
                </motion.div>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <motion.div whileFocus={{ scale: 1.01 }} transition={{ duration: 0.2 }}>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Digite sua redação completa aqui... 

Dica: Uma redação ENEM ideal tem entre 250-400 palavras e deve seguir a estrutura:
• Introdução (apresentação do tema + tese)
• Desenvolvimento 1 (argumento + repertório)
• Desenvolvimento 2 (argumento + repertório) 
• Conclusão (retomada + proposta de intervenção)"
                className="min-h-[400px] resize-none hover-glow transition-all duration-300 focus:min-h-[500px]"
                disabled={isLoading}
              />
            </motion.div>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mt-4 space-y-3 md:space-y-0">
              <p className="text-sm text-muted-foreground">
                Escreva sobre um tema do ENEM seguindo a estrutura dissertativo-argumentativa com proposta de
                intervenção.
              </p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={analyzeRedacao}
                  disabled={!text.trim() || isLoading}
                  className="btn-animate bg-primary hover:bg-primary/90 w-full md:w-auto"
                >
                  {isLoading ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                      >
                        <Loader2 className="h-4 w-4 mr-2" />
                      </motion.div>
                      Analisando com IA...
                    </>
                  ) : (
                    <>
                      <Trophy className="h-4 w-4 mr-2" />
                      Analisar para Nota 1000
                    </>
                  )}
                </Button>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        whileHover={{ scale: 1.02 }}
      >
        <Card className="hover-glow bg-gradient-to-r from-primary/10 to-accent/10 border-primary/30">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center space-x-2">
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 15, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                >
                  <Trophy className="h-6 w-6 text-primary" />
                </motion.div>
                <h3 className="text-xl font-semibold text-white">Quer se tornar um especialista em redação?</h3>
              </div>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Aprenda técnicas avançadas de redação com nosso treinamento profissional completo. Metodologia
                comprovada para alcançar a nota 1000 no ENEM.
              </p>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  asChild
                  className="btn-animate bg-primary hover:bg-primary/90 text-white font-semibold px-6 py-3"
                  size="lg"
                >
                  <a
                    href="https://aluno.coredacao.com/?etapa=4"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-2"
                  >
                    <span>Acessar Treinamento Profissional</span>
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Results */}
      <AnimatePresence>
        {result && (
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, type: "spring" }}
            >
              <Card className="hover-lift">
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center space-x-4 mb-4">
                      {result.grade_level && (
                        <motion.div
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.2 }}
                        >
                          <Badge className={`${getGradeLevelColor(result.grade_level)} px-3 py-1`}>
                            Nível: {result.grade_level}
                          </Badge>
                        </motion.div>
                      )}
                      {result.improvement_priority && (
                        <motion.div
                          initial={{ x: 20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.3 }}
                        >
                          <Badge variant="outline" className="px-3 py-1">
                            <Target className="h-3 w-3 mr-1" />
                            Foco: {result.improvement_priority}
                          </Badge>
                        </motion.div>
                      )}
                    </div>
                    <motion.div
                      className={`text-6xl md:text-8xl font-bold mb-2 ${getScoreColor(result.score)}`}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.4, duration: 0.8, type: "spring" }}
                    >
                      {result.score}
                    </motion.div>
                    <div className="text-2xl text-muted-foreground mb-4">/1000</div>
                    <motion.div
                      className="max-w-2xl mx-auto"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.6 }}
                    >
                      <p className="text-lg text-foreground leading-relaxed">{result.comments}</p>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-primary" />
                    <span>Avaliação por Competências ENEM</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="overview" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="overview">Visão Geral</TabsTrigger>
                      <TabsTrigger value="detailed">Análise Detalhada</TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview" className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {Object.entries(result.competencies).map(([key, value], index) => (
                          <motion.div
                            key={key}
                            className="space-y-3"
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.1 * index, duration: 0.4 }}
                          >
                            <div className="flex justify-between items-center">
                              <span className="text-sm font-medium text-white">
                                {competencyLabels[key as keyof typeof competencyLabels]}
                              </span>
                              <Badge variant="outline" className="font-bold">
                                {value}/200
                              </Badge>
                            </div>
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: "100%" }}
                              transition={{ delay: 0.2 * index, duration: 0.8 }}
                            >
                              <Progress value={(value / 200) * 100} className="h-3" />
                            </motion.div>
                          </motion.div>
                        ))}
                      </div>
                    </TabsContent>

                    <TabsContent value="detailed" className="space-y-4">
                      {result.detailed_analysis && (
                        <div className="space-y-4">
                          {Object.entries(result.detailed_analysis).map(([key, analysis], index) => (
                            <motion.div
                              key={key}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.1 * index, duration: 0.4 }}
                            >
                              <Card className="bg-muted/30">
                                <CardContent className="pt-4">
                                  <div className="flex items-start space-x-3">
                                    <BookOpen className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
                                    <div>
                                      <h4 className="font-semibold text-white mb-2">
                                        {competencyLabels[key as keyof typeof competencyLabels]}
                                      </h4>
                                      <p className="text-sm text-muted-foreground leading-relaxed">{analysis}</p>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </motion.div>

            {/* Strengths and Weaknesses */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="hover-lift">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-green-400">
                      <CheckCircle className="h-5 w-5" />
                      <span>Pontos Fortes</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {result.strengths.map((strength, index) => (
                        <motion.li
                          key={index}
                          className="flex items-start space-x-3"
                          style={{ animationDelay: `${index * 0.1}s` }}
                        >
                          <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground leading-relaxed">{strength}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="hover-lift">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-yellow-400">
                      <AlertCircle className="h-5 w-5" />
                      <span>Pontos a Melhorar</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {result.weaknesses.map((weakness, index) => (
                        <motion.li
                          key={index}
                          className="flex items-start space-x-3"
                          style={{ animationDelay: `${index * 0.1}s` }}
                        >
                          <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground leading-relaxed">{weakness}</span>
                        </motion.li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </motion.div>

            {/* Suggestions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.6 }}
            >
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lightbulb className="h-5 w-5 text-primary" />
                    <span>Sugestões de Melhoria</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {result.suggestions.map((suggestion, index) => (
                      <motion.div
                        key={index}
                        className="p-4 bg-muted/50 rounded-lg border-l-4 border-primary hover-glow animate-slide-in"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className="flex items-start space-x-2">
                          <TrendingUp className="h-4 w-4 text-primary mt-1 flex-shrink-0" />
                          <p className="text-sm text-muted-foreground leading-relaxed">{suggestion}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Example Phrases */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.6 }}
            >
              <Card className="hover-lift">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5 text-primary" />
                    <span>Frases para Enriquecer seu Repertório</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {result.example_phrases.map((phrase, index) => (
                      <motion.div
                        key={index}
                        className="p-4 bg-primary/10 rounded-lg border-l-4 border-primary hover-glow animate-slide-in"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <p className="text-sm italic text-muted-foreground leading-relaxed">"{phrase}"</p>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
