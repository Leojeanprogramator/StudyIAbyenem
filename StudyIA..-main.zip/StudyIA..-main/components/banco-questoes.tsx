"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Filter } from "lucide-react"

interface Question {
  id: number
  subject: string
  difficulty: string
  question: string
  alternatives: string[]
  answer: string
  explanation: string
  topic: string
}

export function BancoQuestoes() {
  const [selectedSubject, setSelectedSubject] = useState<string>("all")
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all")

  // Mock data - em produção viria de uma API/banco de dados
  const mockQuestions: Question[] = [
    {
      id: 1,
      subject: "Matemática",
      difficulty: "Médio",
      topic: "Funções",
      question: "Uma função f(x) = 2x + 3 tem como valor f(5) igual a:",
      alternatives: ["11", "13", "15", "17", "19"],
      answer: "B",
      explanation: "Substituindo x = 5 na função: f(5) = 2(5) + 3 = 10 + 3 = 13",
    },
    {
      id: 2,
      subject: "Português",
      difficulty: "Fácil",
      topic: "Interpretação de Texto",
      question: 'No texto "O gato subiu no telhado", a palavra "gato" exerce função de:',
      alternatives: ["Objeto direto", "Sujeito", "Predicado", "Adjunto adverbial", "Complemento nominal"],
      answer: "B",
      explanation: "O gato é quem pratica a ação de subir, portanto é o sujeito da oração.",
    },
    {
      id: 3,
      subject: "Biologia",
      difficulty: "Difícil",
      topic: "Genética",
      question:
        "Em um cruzamento entre dois indivíduos heterozigotos (Aa x Aa), a probabilidade de nascer um descendente homozigoto recessivo é:",
      alternatives: ["0%", "25%", "50%", "75%", "100%"],
      answer: "B",
      explanation:
        "No cruzamento Aa x Aa, temos: AA (25%), Aa (50%), aa (25%). Portanto, 25% de chance para homozigoto recessivo (aa).",
    },
  ]

  const subjects = ["all", "Matemática", "Português", "Biologia", "Química", "Física", "História", "Geografia"]
  const difficulties = ["all", "Fácil", "Médio", "Intermediário", "Difícil"]

  const filteredQuestions = mockQuestions.filter((question) => {
    const subjectMatch = selectedSubject === "all" || question.subject === selectedSubject
    const difficultyMatch = selectedDifficulty === "all" || question.difficulty === selectedDifficulty
    return subjectMatch && difficultyMatch
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Fácil":
        return "bg-green-500"
      case "Médio":
        return "bg-yellow-500"
      case "Intermediário":
        return "bg-orange-500"
      case "Difícil":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filtros</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Matéria</label>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as matérias</SelectItem>
                  {subjects.slice(1).map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Dificuldade</label>
              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as dificuldades</SelectItem>
                  {difficulties.slice(1).map((difficulty) => (
                    <SelectItem key={difficulty} value={difficulty}>
                      {difficulty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-primary">{filteredQuestions.length}</div>
            <p className="text-sm text-muted-foreground">Questões encontradas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-500">
              {filteredQuestions.filter((q) => q.difficulty === "Fácil").length}
            </div>
            <p className="text-sm text-muted-foreground">Fáceis</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-yellow-500">
              {filteredQuestions.filter((q) => q.difficulty === "Médio").length}
            </div>
            <p className="text-sm text-muted-foreground">Médias</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-red-500">
              {filteredQuestions.filter((q) => q.difficulty === "Difícil").length}
            </div>
            <p className="text-sm text-muted-foreground">Difíceis</p>
          </CardContent>
        </Card>
      </div>

      {/* Questions */}
      <div className="space-y-4">
        {filteredQuestions.map((question) => (
          <Card key={question.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <span className="font-medium">{question.subject}</span>
                  <Badge variant="outline">{question.topic}</Badge>
                </div>
                <Badge className={`text-white ${getDifficultyColor(question.difficulty)}`}>{question.difficulty}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="font-medium text-lg">{question.question}</p>

                <div className="space-y-2">
                  {question.alternatives.map((alternative, index) => {
                    const letter = String.fromCharCode(65 + index)
                    const isCorrect = question.answer === letter

                    return (
                      <div
                        key={index}
                        className={`p-3 rounded-lg border ${
                          isCorrect ? "border-green-500 bg-green-50 text-green-800" : "border-border bg-muted"
                        }`}
                      >
                        <span className="font-medium">{letter})</span> {alternative}
                        {isCorrect && <Badge className="ml-2 bg-green-500 text-white">Correta</Badge>}
                      </div>
                    )
                  })}
                </div>

                <div className="p-3 bg-primary/10 rounded-lg border-l-4 border-primary">
                  <p className="text-sm">
                    <strong>Explicação:</strong> {question.explanation}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQuestions.length === 0 && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Nenhuma questão encontrada</h3>
              <p className="text-muted-foreground">Tente ajustar os filtros para encontrar questões.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
