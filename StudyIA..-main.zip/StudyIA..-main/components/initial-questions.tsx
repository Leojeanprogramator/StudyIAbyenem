"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface QuestionnaireData {
  subject: string
  studyTime: string
  priority: string
}

interface InitialQuestionsProps {
  onComplete?: (data: QuestionnaireData) => void
}

export function InitialQuestions({ onComplete }: InitialQuestionsProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<QuestionnaireData>({
    subject: "",
    studyTime: "",
    priority: "",
  })
  const [isCompleted, setIsCompleted] = useState(false)

  const questions = [
    {
      id: "subject",
      title: "Qual matéria você tem mais dificuldade?",
      options: [
        { value: "matematica", label: "Matemática" },
        { value: "portugues", label: "Português" },
        { value: "ciencias", label: "Ciências da Natureza" },
        { value: "humanas", label: "Ciências Humanas" },
        { value: "redacao", label: "Redação" },
      ],
    },
    {
      id: "studyTime",
      title: "Quanto tempo você tem disponível por dia?",
      options: [
        { value: "1h", label: "1 hora" },
        { value: "2h", label: "2 horas" },
        { value: "3h", label: "3-4 horas" },
        { value: "5h+", label: "5+ horas" },
      ],
    },
    {
      id: "priority",
      title: "Qual sua prioridade agora?",
      options: [
        { value: "revisao", label: "Revisão de conteúdo" },
        { value: "questoes", label: "Resolver questões" },
        { value: "redacao", label: "Treinar redação" },
        { value: "simulado", label: "Fazer simulados" },
      ],
    },
  ]

  const handleAnswer = (value: string) => {
    const currentQuestion = questions[currentStep]
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: value,
    }))
  }

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setIsCompleted(true)
      onComplete?.(answers)
    }
  }

  const handleSkip = () => {
    setIsCompleted(true)
    onComplete?.(answers)
  }

  if (isCompleted) {
    return (
      <div className="p-6 border-b border-border">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-foreground mb-2">Perfeito! Agora vamos começar seus estudos! 🎯</h3>
          <p className="text-sm text-muted-foreground">
            Digite sua primeira pergunta ou escolha uma das opções abaixo.
          </p>
        </div>
      </div>
    )
  }

  const currentQuestion = questions[currentStep]
  const currentAnswer = answers[currentQuestion.id as keyof QuestionnaireData]

  return (
    <div className="p-6 border-b border-border">
      <Card className="bg-background border-border">
        <CardHeader>
          <CardTitle className="text-lg text-foreground">{currentQuestion.title}</CardTitle>
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>
              Pergunta {currentStep + 1} de {questions.length}
            </span>
            <Button variant="ghost" size="sm" onClick={handleSkip}>
              Pular questionário
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <RadioGroup value={currentAnswer} onValueChange={handleAnswer}>
            {currentQuestion.options.map((option) => (
              <div key={option.value} className="flex items-center space-x-2">
                <RadioGroupItem value={option.value} id={option.value} />
                <Label htmlFor={option.value} className="cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>

          <div className="flex justify-between mt-6">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
            >
              Voltar
            </Button>
            <Button onClick={handleNext} disabled={!currentAnswer}>
              {currentStep === questions.length - 1 ? "Finalizar" : "Próxima"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
