"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Loader2, Clock, CheckCircle, XCircle } from "lucide-react"

interface Question {
  id: number
  question: string
  alternatives: string[]
  answer: string
  explanation: string
}

interface SimuladoConfig {
  materia: string
  numQuestions: number
  difficulty: string
}

export function SimuladoGenerator() {
  const [config, setConfig] = useState<SimuladoConfig>({
    materia: "",
    numQuestions: 10,
    difficulty: "",
  })
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [showResults, setShowResults] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const [timerActive, setTimerActive] = useState(false)

  const materias = [
    { value: "matematica", label: "Matemática" },
    { value: "portugues", label: "Português" },
    { value: "biologia", label: "Biologia" },
    { value: "quimica", label: "Química" },
    { value: "fisica", label: "Física" },
    { value: "historia", label: "História" },
    { value: "geografia", label: "Geografia" },
    { value: "filosofia", label: "Filosofia" },
    { value: "sociologia", label: "Sociologia" },
    { value: "misto", label: "Todas as matérias (Misto)" },
  ]

  const difficulties = [
    { value: "facil", label: "Fácil" },
    { value: "medio", label: "Médio" },
    { value: "intermediario", label: "Intermediário" },
    { value: "dificil", label: "Difícil" },
  ]

  const generateSimulado = async () => {
    if (!config.materia || !config.difficulty) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/simulado/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      })

      if (!response.ok) throw new Error("Erro ao gerar simulado")

      const data = await response.json()
      setQuestions(data.questions)
      setCurrentQuestion(0)
      setAnswers({})
      setShowResults(false)

      // Inicia timer (3 minutos por questão)
      const totalTime = config.numQuestions * 3 * 60
      setTimeLeft(totalTime)
      setTimerActive(true)
    } catch (error) {
      console.error("Erro ao gerar simulado:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const selectAnswer = (questionId: number, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      finishSimulado()
    }
  }

  const finishSimulado = () => {
    setShowResults(true)
    setTimerActive(false)
  }

  const calculateResults = () => {
    let correct = 0
    questions.forEach((q) => {
      if (answers[q.id] === q.answer) correct++
    })
    return {
      correct,
      total: questions.length,
      percentage: Math.round((correct / questions.length) * 100),
    }
  }

  // Timer effect
  React.useEffect(() => {
    if (timerActive && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && timerActive) {
      finishSimulado()
    }
  }, [timeLeft, timerActive])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (showResults) {
    const results = calculateResults()
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Resultado do Simulado</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-6">
            <div className="text-4xl font-bold text-primary mb-2">
              {results.correct}/{results.total}
            </div>
            <div className="text-lg text-muted-foreground">{results.percentage}% de acertos</div>
          </div>

          <div className="space-y-4">
            {questions.map((question, index) => {
              const userAnswer = answers[question.id]
              const isCorrect = userAnswer === question.answer

              return (
                <div key={question.id} className="border border-border rounded-lg p-4">
                  <div className="flex items-start space-x-2 mb-2">
                    {isCorrect ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500 mt-1" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium mb-2">
                        {index + 1}. {question.question}
                      </p>

                      <div className="space-y-1 mb-2">
                        {question.alternatives.map((alt, altIndex) => {
                          const letter = String.fromCharCode(65 + altIndex)
                          const isUserAnswer = userAnswer === letter
                          const isCorrectAnswer = question.answer === letter

                          return (
                            <div
                              key={altIndex}
                              className={`p-2 rounded text-sm ${
                                isCorrectAnswer
                                  ? "bg-green-100 text-green-800 border border-green-300"
                                  : isUserAnswer
                                    ? "bg-red-100 text-red-800 border border-red-300"
                                    : "bg-muted"
                              }`}
                            >
                              {letter}) {alt}
                            </div>
                          )
                        })}
                      </div>

                      <p className="text-sm text-muted-foreground">
                        <strong>Explicação:</strong> {question.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          <div className="text-center mt-6">
            <Button
              onClick={() => {
                setQuestions([])
                setShowResults(false)
                setAnswers({})
              }}
            >
              Fazer Novo Simulado
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (questions.length > 0) {
    const question = questions[currentQuestion]
    const progress = ((currentQuestion + 1) / questions.length) * 100

    return (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>
              Questão {currentQuestion + 1} de {questions.length}
            </CardTitle>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{formatTime(timeLeft)}</span>
              </Badge>
            </div>
          </div>
          <Progress value={progress} className="mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-lg font-medium">{question.question}</p>

            <div className="space-y-2">
              {question.alternatives.map((alternative, index) => {
                const letter = String.fromCharCode(65 + index)
                const isSelected = answers[question.id] === letter

                return (
                  <button
                    key={index}
                    onClick={() => selectAnswer(question.id, letter)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      isSelected
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:border-primary/50 hover:bg-accent"
                    }`}
                  >
                    <span className="font-medium">{letter})</span> {alternative}
                  </button>
                )
              })}
            </div>

            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                disabled={currentQuestion === 0}
              >
                Anterior
              </Button>

              <Button onClick={nextQuestion} disabled={!answers[question.id]}>
                {currentQuestion === questions.length - 1 ? "Finalizar" : "Próxima"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurar Simulado</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Matéria</label>
            <Select
              value={config.materia}
              onValueChange={(value) => setConfig((prev) => ({ ...prev, materia: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione a matéria" />
              </SelectTrigger>
              <SelectContent>
                {materias.map((materia) => (
                  <SelectItem key={materia.value} value={materia.value}>
                    {materia.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Número de Questões</label>
            <Select
              value={config.numQuestions.toString()}
              onValueChange={(value) => setConfig((prev) => ({ ...prev, numQuestions: Number.parseInt(value) }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 questões</SelectItem>
                <SelectItem value="10">10 questões</SelectItem>
                <SelectItem value="15">15 questões</SelectItem>
                <SelectItem value="20">20 questões</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Dificuldade</label>
            <Select
              value={config.difficulty}
              onValueChange={(value) => setConfig((prev) => ({ ...prev, difficulty: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione a dificuldade" />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty.value} value={difficulty.value}>
                    {difficulty.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={generateSimulado}
            disabled={!config.materia || !config.difficulty || isLoading}
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Gerando Simulado...
              </>
            ) : (
              "Gerar Simulado"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
