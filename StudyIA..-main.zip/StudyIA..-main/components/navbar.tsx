"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, PenTool, MessageCircle, Calendar, ExternalLink, HelpCircle, Youtube } from "lucide-react"
import Image from "next/image"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const navigation = [
    { name: "Chat IA", href: "/", icon: MessageCircle },
    { name: "Nota Mil IA", href: "/redacao", icon: PenTool },
    { name: "Sites de Simulados", href: "/sites-simulados", icon: ExternalLink },
    { name: "Cronograma ENEM", href: "/cronograma", icon: Calendar },
    { name: "Canais YouTube", href: "/canais-youtube", icon: Youtube },
    { name: "Dicas de Estudo", href: "/dicas-estudo", icon: HelpCircle },
  ]

  return (
    <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <Link
              href="/"
              className="flex items-center space-x-2 hover-glow transition-all duration-300 cursor-pointer"
            >
              <Image
                src="https://i.postimg.cc/MpSGBDp6/Design-sem-nome-5-removebg-preview.png"
                alt="Study IA Logo"
                width={64}
                height={64}
                className="object-contain opacity-100"
              />
              <span className="text-2xl font-bold text-white hover:text-primary transition-colors duration-300">
                Study IA
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-2">
              {navigation.map((item) => {
                const Icon = item.icon
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white hover:bg-primary/20 transition-all duration-300 hover-glow"
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.name}</span>
                  </Link>
                )
              })}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" onClick={() => setIsOpen(!isOpen)} className="hover-glow">
              {isOpen ? <X className="h-6 w-6 text-white" /> : <Menu className="h-6 w-6 text-white" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden animate-slide-in">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-border bg-card/50 backdrop-blur">
            {navigation.map((item, index) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium text-gray-300 hover:text-white hover:bg-primary/20 transition-all duration-300 animate-slide-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                  onClick={() => setIsOpen(false)}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              )
            })}
          </div>
        </div>
      )}
    </nav>
  )
}
