import { SimuladoGenerator } from "@/components/simulado-generator"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, BookOpen, Target } from "lucide-react"

export default function SimuladosPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Simulados Personalizados</h1>
            <p className="text-lg text-muted-foreground">Pratique com questões geradas por IA no padrão ENEM</p>
          </div>

          <SimuladoGenerator />

          <div className="mt-12 space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-foreground mb-4">Questões Complementares</h2>
              <p className="text-muted-foreground mb-6">
                Além dos simulados personalizados, pratique com milhares de questões organizadas por disciplina
              </p>
            </div>

            <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 hover-glow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-primary/20 rounded-lg">
                    <BookOpen className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl font-bold text-foreground">Prisma Questões</CardTitle>
                    <CardDescription className="text-muted-foreground">
                      Plataforma especializada em questões do ENEM organizadas por disciplina e dificuldade
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-primary" />
                    <span className="text-sm text-muted-foreground">Questões organizadas por matéria</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-primary" />
                    <span className="text-sm text-muted-foreground">Filtros por dificuldade</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-primary" />
                    <span className="text-sm text-muted-foreground">Questões de anos anteriores</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-primary" />
                    <span className="text-sm text-muted-foreground">Estatísticas de desempenho</span>
                  </div>
                </div>

                <Button asChild className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" size="lg">
                  <a
                    href="https://estudeprisma.com/questoes"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2"
                  >
                    <span>Acessar Prisma Questões</span>
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
