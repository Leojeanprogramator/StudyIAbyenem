import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, Lightbulb, TrendingUp, CheckCircle, AlertCircle, Zap, Play, Youtube, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function DicasEstudoPage() {
  const youtubeVideos = [
    {
      category: "enem",
      title: "Como eu estudaria para ser aprovado no ENEM 2025 começando hoje",
      channel: "YouTube",
      url: "https://www.youtube.com/watch?v=AmiqGXWMvxU",
      duration: "15:30",
      description: "Estratégia completa para começar a estudar para o ENEM 2025",
    },
    {
      category: "enem",
      title: "2 meses para o ENEM: ainda dá?",
      channel: "YouTube",
      url: "https://www.youtube.com/watch?v=3zYriNRrNjg",
      duration: "12:45",
      description: "Como se preparar para o ENEM em pouco tempo",
    },
    {
      category: "enem",
      title: "ESTRATÉGIA DE PROVA PARA GABARITAR O PRIMEIRO DIA DO ENEM",
      channel: "YouTube",
      url: "https://www.youtube.com/watch?v=GUCEIAUQJW8",
      duration: "18:20",
      description: "Técnicas para maximizar sua performance no primeiro dia",
    },
    {
      category: "enem",
      title: "😱 VAZOU! CONTEÚDOS QUE VÃO CAIR NO ENEM 2025",
      channel: "YouTube",
      url: "https://www.youtube.com/watch?v=1bd_r4K_nu4",
      duration: "14:15",
      description: "Principais temas que podem aparecer no ENEM 2025",
    },
  ]

  const dicasCategories = [
    {
      id: "enem",
      name: "Estratégias ENEM",
      icon: Zap,
      color: "bg-red-500",
      tips: [
        {
          title: "Domine a Gestão de Tempo na Prova",
          description: "1 minuto por questão objetiva, 30 minutos para redação. Treine com cronômetro nos simulados.",
          priority: "alta",
          time: "Prática constante",
          category: "Prova",
        },
        {
          title: "Leia as Questões Estrategicamente",
          description:
            "Leia o enunciado, depois as alternativas, e só então o texto. Isso economiza tempo e melhora a compreensão.",
          priority: "alta",
          time: "Técnica imediata",
          category: "Leitura",
        },
        {
          title: "Foque nos Assuntos que Mais Caem",
          description:
            "80% das questões vêm de 20% do conteúdo. Priorize interpretação de texto, funções e atualidades.",
          priority: "alta",
          time: "Revisão do cronograma",
          category: "Priorização",
        },
        {
          title: "Crie um Cronograma Realista",
          description: "Divida o conteúdo em blocos diários de 2-3 horas, incluindo pausas de 15 minutos a cada hora.",
          priority: "alta",
          time: "Implementação: 1 dia",
          category: "Planejamento",
        },
        {
          title: "Use a Técnica Pomodoro",
          description:
            "25 minutos de estudo focado + 5 minutos de pausa. A cada 4 ciclos, faça uma pausa de 30 minutos.",
          priority: "alta",
          time: "Aplicação imediata",
          category: "Produtividade",
        },
        {
          title: "Técnica de Repetição Espaçada",
          description: "Revise o conteúdo após 1 dia, 3 dias, 1 semana, 2 semanas e 1 mês para fixação permanente.",
          priority: "alta",
          time: "Processo contínuo",
          category: "Revisão",
        },
        {
          title: "Crie Mapas Mentais",
          description:
            "Conecte conceitos visualmente usando cores, símbolos e palavras-chave para facilitar a memorização.",
          priority: "alta",
          time: "20-30 min por tópico",
          category: "Visual",
        },
        {
          title: "Elimine Distrações Digitais",
          description: "Use apps bloqueadores de redes sociais durante o estudo. Deixe o celular em outro cômodo.",
          priority: "alta",
          time: "Configuração: 10 min",
          category: "Foco",
        },
        {
          title: "Mantenha uma Rotina de Sono",
          description: "Durma 7-8 horas por noite. O sono é essencial para consolidação da memória e concentração.",
          priority: "alta",
          time: "Rotina diária",
          category: "Sono",
        },
      ],
    },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "alta":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "media":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const quickTips = [
    "Estude 2-3 horas por dia de forma consistente é melhor que 8 horas esporádicas",
    "Faça pausas regulares - seu cérebro precisa de tempo para processar informações",
    "Ensine o que aprendeu para alguém - é a melhor forma de testar seu conhecimento",
    "Use diferentes sentidos: leia, escreva, fale e desenhe o conteúdo",
    "Mantenha um caderno de erros para revisar suas principais dificuldades",
  ]

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header Section */}
          <div className="text-center mb-12 animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
              <span className="text-primary">Dicas de Estudo</span> Eficazes
            </h1>
            <p className="text-xl text-muted-foreground mb-6 text-pretty max-w-4xl mx-auto">
              Estratégias comprovadas cientificamente para maximizar seu aprendizado e performance no ENEM. Transforme
              sua rotina de estudos com técnicas eficazes.
            </p>

            {/* Quick Tips Banner */}
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 max-w-4xl mx-auto mb-8 hover-glow">
              <div className="flex items-start space-x-3">
                <Lightbulb className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                <div className="text-left">
                  <h3 className="text-lg font-semibold text-foreground mb-3">Dicas Rápidas para Hoje</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {quickTips.slice(0, 4).map((tip, index) => (
                      <div
                        key={index}
                        className="flex items-start space-x-2 animate-slide-in"
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-muted-foreground">{tip}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Tabs defaultValue="enem" className="mb-8">
            <TabsList className="grid w-full grid-cols-1 bg-card">
              <TabsTrigger value="enem" className="transition-all duration-300">
                Estratégias ENEM
              </TabsTrigger>
            </TabsList>

            {dicasCategories.map((category) => {
              const Icon = category.icon
              const categoryVideos = youtubeVideos.filter((video) => video.category === category.id)

              return (
                <TabsContent key={category.id} value={category.id} className="mt-6">
                  <div className="space-y-8">
                    <div className="flex items-center space-x-3 mb-6 animate-slide-in">
                      <div className={`p-3 rounded-lg ${category.color}`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <h2 className="text-2xl font-bold text-foreground">{category.name}</h2>
                    </div>

                    {categoryVideos.length > 0 && (
                      <div className="mb-8">
                        <div className="flex items-center space-x-2 mb-4">
                          <Youtube className="h-5 w-5 text-red-500" />
                          <h3 className="text-lg font-semibold text-foreground">Vídeos Recomendados - ENEM 2025</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {categoryVideos.map((video, index) => (
                            <Card
                              key={index}
                              className="bg-card border-border hover:border-primary/50 transition-all duration-300 hover-lift animate-slide-in"
                              style={{ animationDelay: `${index * 0.1}s` }}
                            >
                              <CardContent className="p-4">
                                <div className="flex space-x-4">
                                  <div className="relative flex-shrink-0">
                                    <div className="w-24 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center">
                                      <Play className="h-6 w-6 text-white" />
                                    </div>
                                    <Badge className="absolute -bottom-1 -right-1 text-xs bg-black/80 text-white">
                                      {video.duration}
                                    </Badge>
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <h4 className="font-semibold text-sm text-foreground mb-1 line-clamp-2">
                                      {video.title}
                                    </h4>
                                    <p className="text-xs text-primary mb-2">{video.channel}</p>
                                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                                      {video.description}
                                    </p>
                                    <Button
                                      asChild
                                      size="sm"
                                      className="w-full bg-red-600 hover:bg-red-700 text-white text-xs"
                                    >
                                      <a
                                        href={video.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center justify-center space-x-1"
                                      >
                                        <Youtube className="h-3 w-3" />
                                        <span>Assistir</span>
                                        <ExternalLink className="h-3 w-3" />
                                      </a>
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {category.tips.map((tip, index) => (
                        <Card
                          key={index}
                          className="bg-card border-border hover:border-primary/50 transition-all duration-300 hover-lift animate-slide-in"
                          style={{ animationDelay: `${index * 0.1}s` }}
                        >
                          <CardHeader>
                            <div className="flex items-start justify-between mb-2">
                              <CardTitle className="text-lg font-bold text-foreground">{tip.title}</CardTitle>
                              <Badge className={getPriorityColor(tip.priority)}>
                                {tip.priority === "alta" ? "Alta" : "Média"} Prioridade
                              </Badge>
                            </div>
                            <CardDescription className="text-muted-foreground">{tip.description}</CardDescription>
                          </CardHeader>

                          <CardContent className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center space-x-1 text-muted-foreground">
                                <Clock className="h-4 w-4" />
                                <span>{tip.time}</span>
                              </div>
                              <Badge variant="secondary" className="text-xs">
                                {tip.category}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              )
            })}
          </Tabs>

          {/* Study Myths vs Facts */}
          <div className="mt-12 bg-card border border-border rounded-lg p-6 hover-glow animate-fade-in">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center">Mitos vs Realidade dos Estudos</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-red-400 mb-4 flex items-center">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  Mitos Prejudiciais
                </h4>
                <div className="space-y-3">
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-red-400">"Estudar a noite toda é eficaz"</strong>
                      <br />A privação de sono prejudica a memória e concentração
                    </p>
                  </div>
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-red-400">"Reler é a melhor forma de estudar"</strong>
                      <br />
                      Releitura passiva é uma das técnicas menos eficazes
                    </p>
                  </div>
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-red-400">"Multitasking aumenta a produtividade"</strong>
                      <br />
                      Dividir atenção reduz a qualidade do aprendizado
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-green-400 mb-4 flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Fatos Comprovados
                </h4>
                <div className="space-y-3">
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-green-400">"Teste ativo é mais eficaz"</strong>
                      <br />
                      Fazer questões e resumos melhora a retenção em 50%
                    </p>
                  </div>
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-green-400">"Pausas melhoram o aprendizado"</strong>
                      <br />O cérebro consolida informações durante os intervalos
                    </p>
                  </div>
                  <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg hover-glow transition-all duration-300">
                    <p className="text-sm text-muted-foreground">
                      <strong className="text-green-400">"Variar locais de estudo ajuda"</strong>
                      <br />
                      Diferentes ambientes fortalecem as conexões neurais
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Plan */}
          <div className="mt-12 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-8 text-center hover-glow animate-fade-in">
            <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-foreground mb-4">Comece Sua Transformação Hoje</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Escolha 2-3 dicas desta página e implemente gradualmente. Pequenas mudanças consistentes geram grandes
              resultados no ENEM.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
              <div className="bg-background/50 rounded-lg p-4 hover-lift transition-all duration-300">
                <div className="text-lg font-bold text-primary">Semana 1</div>
                <div className="text-sm text-muted-foreground">Organize espaço e cronograma</div>
              </div>
              <div className="bg-background/50 rounded-lg p-4 hover-lift transition-all duration-300">
                <div className="text-lg font-bold text-primary">Semana 2</div>
                <div className="text-sm text-muted-foreground">Implemente técnicas de memorização</div>
              </div>
              <div className="bg-background/50 rounded-lg p-4 hover-lift transition-all duration-300">
                <div className="text-lg font-bold text-primary">Semana 3+</div>
                <div className="text-sm text-muted-foreground">Otimize concentração e bem-estar</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
