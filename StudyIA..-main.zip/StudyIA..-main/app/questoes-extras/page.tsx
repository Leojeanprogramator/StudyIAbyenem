"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Calculator, Atom, Users, Play, CheckCircle, Clock, Target } from "lucide-react"

export default function QuestoesExtrasPage() {
  const [selectedSubject, setSelectedSubject] = useState("todas")

  const questoesCategories = [
    {
      id: "matematica",
      name: "Matemática",
      icon: Calculator,
      color: "bg-blue-500",
      questions: [
        {
          title: "Funções Quadráticas - Nível Avançado",
          description: "10 questões sobre vértice, discriminante e gráficos de funções quadráticas",
          difficulty: "Difícil",
          time: "25 min",
          topics: ["Funções", "Gráficos", "Análise"],
        },
        {
          title: "Estatística e Probabilidade",
          description: "15 questões sobre média, mediana, moda e cálculo de probabilidades",
          difficulty: "Médio",
          time: "30 min",
          topics: ["Estatística", "Probabilidade", "Análise de Dados"],
        },
        {
          title: "Geometria Plana Essencial",
          description: "12 questões sobre áreas, perímetros e teoremas fundamentais",
          difficulty: "Médio",
          time: "20 min",
          topics: ["Geometria", "Áreas", "Teoremas"],
        },
      ],
    },
    {
      id: "linguagens",
      name: "Linguagens",
      icon: BookOpen,
      color: "bg-green-500",
      questions: [
        {
          title: "Interpretação de Texto Avançada",
          description: "8 textos complexos com questões de inferência e análise crítica",
          difficulty: "Difícil",
          time: "35 min",
          topics: ["Interpretação", "Inferência", "Análise Crítica"],
        },
        {
          title: "Figuras de Linguagem",
          description: "20 questões sobre metáfora, metonímia, ironia e outras figuras",
          difficulty: "Médio",
          time: "25 min",
          topics: ["Figuras de Linguagem", "Estilística", "Semântica"],
        },
        {
          title: "Literatura Brasileira Contemporânea",
          description: "15 questões sobre autores e obras do século XX e XXI",
          difficulty: "Médio",
          time: "30 min",
          topics: ["Literatura", "Autores Brasileiros", "Análise Literária"],
        },
      ],
    },
    {
      id: "natureza",
      name: "Ciências da Natureza",
      icon: Atom,
      color: "bg-purple-500",
      questions: [
        {
          title: "Ecologia e Meio Ambiente",
          description: "18 questões sobre cadeias alimentares, biomas e sustentabilidade",
          difficulty: "Médio",
          time: "30 min",
          topics: ["Ecologia", "Biomas", "Sustentabilidade"],
        },
        {
          title: "Eletroquímica Avançada",
          description: "12 questões sobre pilhas, eletrólise e corrosão",
          difficulty: "Difícil",
          time: "25 min",
          topics: ["Eletroquímica", "Pilhas", "Eletrólise"],
        },
        {
          title: "Energia e Transformações",
          description: "15 questões sobre energia cinética, potencial e conservação",
          difficulty: "Médio",
          time: "28 min",
          topics: ["Energia", "Física", "Conservação"],
        },
      ],
    },
    {
      id: "humanas",
      name: "Ciências Humanas",
      icon: Users,
      color: "bg-orange-500",
      questions: [
        {
          title: "Movimentos Sociais no Brasil",
          description: "14 questões sobre MST, movimento negro e direitos humanos",
          difficulty: "Médio",
          time: "25 min",
          topics: ["Movimentos Sociais", "Direitos Humanos", "História do Brasil"],
        },
        {
          title: "Geopolítica Mundial",
          description: "16 questões sobre conflitos, blocos econômicos e globalização",
          difficulty: "Difícil",
          time: "32 min",
          topics: ["Geopolítica", "Globalização", "Relações Internacionais"],
        },
        {
          title: "Urbanização e Demografia",
          description: "12 questões sobre crescimento urbano e indicadores demográficos",
          difficulty: "Médio",
          time: "22 min",
          topics: ["Urbanização", "Demografia", "Geografia Urbana"],
        },
      ],
    },
  ]

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Fácil":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "Médio":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Difícil":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const filteredCategories =
    selectedSubject === "todas" ? questoesCategories : questoesCategories.filter((cat) => cat.id === selectedSubject)

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
              <span className="text-primary">Questões Extras</span> ENEM
            </h1>
            <p className="text-xl text-muted-foreground mb-6 text-pretty max-w-4xl mx-auto">
              Pratique com questões adicionais organizadas por disciplina e nível de dificuldade. Perfeito para reforçar
              o aprendizado e testar seus conhecimentos.
            </p>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto mb-8">
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary">150+</div>
                <div className="text-sm text-muted-foreground">Questões Disponíveis</div>
              </div>
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary">4</div>
                <div className="text-sm text-muted-foreground">Áreas do Conhecimento</div>
              </div>
              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary">3</div>
                <div className="text-sm text-muted-foreground">Níveis de Dificuldade</div>
              </div>
            </div>
          </div>

          {/* Filter Tabs */}
          <Tabs value={selectedSubject} onValueChange={setSelectedSubject} className="mb-8">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 bg-card">
              <TabsTrigger value="todas">Todas</TabsTrigger>
              <TabsTrigger value="matematica">Matemática</TabsTrigger>
              <TabsTrigger value="linguagens">Linguagens</TabsTrigger>
              <TabsTrigger value="natureza">Natureza</TabsTrigger>
              <TabsTrigger value="humanas">Humanas</TabsTrigger>
            </TabsList>

            <TabsContent value={selectedSubject} className="mt-6">
              <div className="space-y-8">
                {filteredCategories.map((category) => {
                  const Icon = category.icon

                  return (
                    <div key={category.id}>
                      <div className="flex items-center space-x-3 mb-6">
                        <div className={`p-3 rounded-lg ${category.color}`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <h2 className="text-2xl font-bold text-foreground">{category.name}</h2>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {category.questions.map((question, index) => (
                          <Card
                            key={index}
                            className="bg-card border-border hover:border-primary/50 transition-colors group"
                          >
                            <CardHeader>
                              <div className="flex items-start justify-between mb-2">
                                <CardTitle className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                                  {question.title}
                                </CardTitle>
                                <Badge className={getDifficultyColor(question.difficulty)}>{question.difficulty}</Badge>
                              </div>
                              <CardDescription className="text-muted-foreground">
                                {question.description}
                              </CardDescription>
                            </CardHeader>

                            <CardContent className="space-y-4">
                              {/* Time and Topics */}
                              <div className="flex items-center justify-between text-sm">
                                <div className="flex items-center space-x-1 text-muted-foreground">
                                  <Clock className="h-4 w-4" />
                                  <span>{question.time}</span>
                                </div>
                                <div className="flex items-center space-x-1 text-primary">
                                  <Target className="h-4 w-4" />
                                  <span>{question.topics.length} tópicos</span>
                                </div>
                              </div>

                              {/* Topics */}
                              <div className="space-y-2">
                                <h4 className="text-sm font-semibold text-foreground">Tópicos abordados:</h4>
                                <div className="flex flex-wrap gap-1">
                                  {question.topics.map((topic, topicIndex) => (
                                    <Badge key={topicIndex} variant="secondary" className="text-xs">
                                      {topic}
                                    </Badge>
                                  ))}
                                </div>
                              </div>

                              {/* Action Buttons */}
                              <div className="flex space-x-2">
                                <Button
                                  className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                                  size="sm"
                                >
                                  <Play className="h-4 w-4 mr-2" />
                                  Iniciar
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-border hover:bg-primary/10 bg-transparent"
                                >
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            </TabsContent>
          </Tabs>

          {/* Study Tips */}
          <div className="mt-12 bg-card border border-border rounded-lg p-6">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center">Como Aproveitar as Questões Extras</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-3 w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Foque nas Dificuldades</h4>
                <p className="text-muted-foreground text-sm">
                  Identifique suas matérias mais fracas e pratique questões específicas dessas áreas
                </p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-3 w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Controle o Tempo</h4>
                <p className="text-muted-foreground text-sm">
                  Use o cronômetro sugerido para simular as condições reais da prova do ENEM
                </p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 rounded-full p-3 w-12 h-12 mx-auto mb-3 flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground mb-2">Revise os Erros</h4>
                <p className="text-muted-foreground text-sm">
                  Analise cada erro cometido e estude o conteúdo relacionado antes de prosseguir
                </p>
              </div>
            </div>
          </div>

          {/* Coming Soon */}
          <div className="mt-12 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-8 text-center">
            <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-foreground mb-4">Mais Questões em Breve</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Estamos constantemente adicionando novas questões e funcionalidades. Em breve teremos questões geradas por
              IA personalizadas para seu perfil de estudo.
            </p>
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 bg-transparent">
              Notificar Quando Disponível
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
