import { PerfilDashboard } from "@/components/perfil-dashboard"

export default function PerfilPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Seu Progresso</h1>
            <p className="text-lg text-muted-foreground">Acompanhe sua evolução e conquiste seus objetivos</p>
          </div>

          <PerfilDashboard />
        </div>
      </div>
    </div>
  )
}
