import { Chat } from "@/components/chat"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background grid-pattern">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8">
        <div className="max-w-7xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-6 sm:mb-8 lg:mb-12 animate-fade-in">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4 text-balance leading-tight">
              Study IA para estudantes
              <span className="text-primary block sm:inline"> conquistando o ENEM</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-6 sm:mb-8 text-pretty max-w-4xl mx-auto px-4">
              Acelere seus estudos com IA. Tire dúvidas, corrija redações, faça simulados e crie planos de estudo
              personalizados.
            </p>
          </div>

          {/* Chat Interface */}
          <div className="bg-card border border-border rounded-lg shadow-lg hover-lift max-w-5xl mx-auto">
            <div className="p-4 sm:p-6 border-b border-border bg-primary/10">
              <div className="text-center">
                <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2">
                  Chat com IA - Seu Professor Particular 24/7
                </h3>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  <strong>Este chat pode ser usado para absolutamente tudo:</strong> tire dúvidas sobre qualquer
                  matéria, peça explicações detalhadas, monte seu plano estratégico para o ENEM, ou simplesmente
                  converse sobre seus estudos. Não há limites - use como seu assistente pessoal de estudos!
                </p>
              </div>
            </div>

            <Chat />
          </div>
        </div>
      </div>
    </div>
  )
}
