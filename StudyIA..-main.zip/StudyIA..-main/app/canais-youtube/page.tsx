"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Users, Video, BookOpen, Calculator, Globe, PenTool, Beaker, History } from "lucide-react"

interface YouTubeChannel {
  name: string
  subscribers: string
  description: string
  category: string
  url: string
  icon: React.ReactNode
  specialties: string[]
}

const channels: YouTubeChannel[] = [
  // Língua Portuguesa e Redação
  {
    name: "Professor Noslen",
    subscribers: "2.8M",
    description: "Canal focado em gramática, interpretação e redação.",
    category: "Português",
    url: "https://www.youtube.com/professornoslen",
    icon: <BookOpen className="h-5 w-5" />,
    specialties: ["Gramática", "Interpretação", "Redação", "Literatura"],
  },
  {
    name: "Redação e Dialogia",
    subscribers: "850K",
    description: "Canal especializado em redação para vestibulares e ENEM.",
    category: "Português",
    url: "https://www.youtube.com/channel/UCxiUB_AtHF1gl4VvMjIq9og",
    icon: <PenTool className="h-5 w-5" />,
    specialties: ["Redação ENEM", "Vestibulares", "Técnicas de Escrita"],
  },
  {
    name: "André Gazola",
    subscribers: "1.2M",
    description: "Professor de redação com foco no ENEM.",
    category: "Português",
    url: "https://www.youtube.com/andregazola",
    icon: <PenTool className="h-5 w-5" />,
    specialties: ["Redação ENEM", "Argumentação", "Estrutura Textual"],
  },
  {
    name: "Prof. Raphael Reis (O Mago da Redação)",
    subscribers: "950K",
    description: "Especialista em redação para concursos e vestibulares.",
    category: "Português",
    url: "https://www.youtube.com/@profraphaelreis",
    icon: <PenTool className="h-5 w-5" />,
    specialties: ["Redação", "Concursos", "Vestibulares", "Técnicas Avançadas"],
  },

  // Matemática
  {
    name: "Professor Ferretto",
    subscribers: "2.3M",
    description: "Canal com aulas de matemática para ENEM e vestibulares.",
    category: "Matemática",
    url: "https://www.youtube.com/professorferretto",
    icon: <Calculator className="h-5 w-5" />,
    specialties: ["Funções", "Geometria", "Estatística", "Probabilidade"],
  },
  {
    name: "Mathematics with Professor Rafael Procopio",
    subscribers: "1.7M",
    description: "Aulas de matemática básica e avançada.",
    category: "Matemática",
    url: "https://www.youtube.com/user/matematicario/videos",
    icon: <Calculator className="h-5 w-5" />,
    specialties: ["Matemática Básica", "Matemática Avançada", "Álgebra", "Cálculo"],
  },
  {
    name: "Dicasdemat Sandro Curió",
    subscribers: "890K",
    description: "Dicas e macetes de matemática para ENEM e vestibulares.",
    category: "Matemática",
    url: "https://www.youtube.com/@sandrocuriodicasdemat",
    icon: <Calculator className="h-5 w-5" />,
    specialties: ["Dicas", "Macetes", "Resolução Rápida", "ENEM"],
  },

  // Ciências da Natureza
  {
    name: "Professor Boaro",
    subscribers: "1.5M",
    description: "Canal de física com foco em vestibulares.",
    category: "Ciências",
    url: "https://www.youtube.com/@professorboaro",
    icon: <Beaker className="h-5 w-5" />,
    specialties: ["Física", "Mecânica", "Eletricidade", "Ondas"],
  },
  {
    name: "Paulo Jubilut",
    subscribers: "2.1M",
    description: "Aulas de biologia para ENEM e vestibulares.",
    category: "Ciências",
    url: "https://www.youtube.com/user/jubilut",
    icon: <Beaker className="h-5 w-5" />,
    specialties: ["Biologia", "Genética", "Ecologia", "Fisiologia"],
  },
  {
    name: "Química Simples",
    subscribers: "780K",
    description: "Aulas de química de forma descomplicada.",
    category: "Ciências",
    url: "https://www.youtube.com/c/Qu%C3%ADmicaSimples",
    icon: <Beaker className="h-5 w-5" />,
    specialties: ["Química Orgânica", "Química Inorgânica", "Reações"],
  },
  {
    name: "Química em Foco",
    subscribers: "650K",
    description: "Canal de química com foco em vestibulares.",
    category: "Ciências",
    url: "https://www.youtube.com/@Qu%C3%ADmicaemFoco",
    icon: <Beaker className="h-5 w-5" />,
    specialties: ["Química", "Vestibulares", "Exercícios", "Teoria"],
  },

  // Ciências Humanas
  {
    name: "Se Liga Nessa História / Professor Walter Solla",
    subscribers: "1.3M",
    description: "Canal de história para vestibulares.",
    category: "Humanas",
    url: "https://www.youtube.com/@seliganessahistoriaa",
    icon: <History className="h-5 w-5" />,
    specialties: ["História Geral", "História do Brasil", "Idade Média", "Contemporânea"],
  },
  {
    name: "Partiu Universidade",
    subscribers: "980K",
    description: "Aulas de história, filosofia e sociologia.",
    category: "Humanas",
    url: "https://www.youtube.com/user/seliganessahistoria1/videos",
    icon: <Globe className="h-5 w-5" />,
    specialties: ["História", "Filosofia", "Sociologia", "Atualidades"],
  },
  {
    name: "Nostalgia",
    subscribers: "1.1M",
    description: "Canal de história com foco em vestibulares.",
    category: "Humanas",
    url: "https://www.youtube.com/@nostalgia",
    icon: <History className="h-5 w-5" />,
    specialties: ["História", "Curiosidades", "Vestibulares", "Cultura"],
  },

  // Diversos Conteúdos
  {
    name: "Nerdologia",
    subscribers: "2.8M",
    description: "Canal que relaciona ciência e cultura pop.",
    category: "Diversos",
    url: "https://www.youtube.com/user/nerdologia",
    icon: <Video className="h-5 w-5" />,
    specialties: ["Ciência", "Cultura Pop", "Curiosidades", "Educação"],
  },
  {
    name: "Manual do Mundo",
    subscribers: "3.5M",
    description: "Experimentos e explicações científicas.",
    category: "Diversos",
    url: "https://www.youtube.com/@manualdomundo",
    icon: <Video className="h-5 w-5" />,
    specialties: ["Experimentos", "Ciência", "DIY", "Educação"],
  },
  {
    name: "Descomplica",
    subscribers: "3.2M",
    description: "Plataforma de ensino com aulas para o ENEM.",
    category: "Diversos",
    url: "https://www.youtube.com/@descomplica",
    icon: <Video className="h-5 w-5" />,
    specialties: ["Todas as Matérias", "ENEM", "Vestibulares", "Aulas ao Vivo"],
  },
  {
    name: "Me Salva!",
    subscribers: "2.8M",
    description: "Aulas de diversas matérias para o ENEM.",
    category: "Diversos",
    url: "https://www.youtube.com/@mesalva",
    icon: <Video className="h-5 w-5" />,
    specialties: ["Videoaulas", "ENEM", "Exercícios", "Revisões"],
  },
  {
    name: "Aula Livre",
    subscribers: "1.4M",
    description: "Canal com aulas de diversas matérias para vestibulares.",
    category: "Diversos",
    url: "https://www.youtube.com/user/aulalivre",
    icon: <Video className="h-5 w-5" />,
    specialties: ["Aulas Gratuitas", "Vestibulares", "Múltiplas Matérias"],
  },
  {
    name: "Canal Inteligente",
    subscribers: "890K",
    description: "Canal com conteúdos de diversas matérias para o ENEM.",
    category: "Diversos",
    url: "https://www.youtube.com/@canalinteligente",
    icon: <Video className="h-5 w-5" />,
    specialties: ["ENEM", "Conteúdo Variado", "Dicas de Estudo"],
  },
]

const categories = ["Todos", "Português", "Matemática", "Ciências", "Humanas", "Diversos"]

export default function CanaisYouTube() {
  const [selectedCategory, setSelectedCategory] = useState("Todos")

  const filteredChannels =
    selectedCategory === "Todos" ? channels : channels.filter((channel) => channel.category === selectedCategory)

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Português":
        return <BookOpen className="h-4 w-4" />
      case "Matemática":
        return <Calculator className="h-4 w-4" />
      case "Ciências":
        return <Beaker className="h-4 w-4" />
      case "Humanas":
        return <History className="h-4 w-4" />
      case "Diversos":
        return <Video className="h-4 w-4" />
      default:
        return <Video className="h-4 w-4" />
    }
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Português":
        return "bg-purple-500/20 text-purple-400 border-purple-500/30"
      case "Matemática":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "Ciências":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30"
      case "Humanas":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "Diversos":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  return (
    <div className="min-h-screen bg-background p-3 sm:p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6 sm:space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 animate-fade-in px-4">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight">Canais do YouTube</h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Os melhores professores e canais educacionais para sua preparação no ENEM. Acesse diretamente e estude com
            os especialistas mais renomados do Brasil.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 animate-slide-in px-4">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="btn-animate hover-glow text-xs sm:text-sm px-3 sm:px-4 py-2 flex items-center gap-2"
              size="sm"
            >
              {getCategoryIcon(category)}
              <span>{category}</span>
            </Button>
          ))}
        </div>

        {/* Channels Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {filteredChannels.map((channel, index) => (
            <Card
              key={channel.name}
              className="hover-lift bg-card border-border animate-fade-in h-full flex flex-col"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="space-y-3 sm:space-y-4 pb-3 sm:pb-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center space-x-2 sm:space-x-3 min-w-0 flex-1">
                    <div className="p-2 bg-primary/20 rounded-lg flex-shrink-0">{channel.icon}</div>
                    <div className="min-w-0 flex-1">
                      <CardTitle className="text-base sm:text-lg text-white leading-tight line-clamp-2">
                        {channel.name}
                      </CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Users className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-xs sm:text-sm text-muted-foreground truncate">
                          {channel.subscribers} inscritos
                        </span>
                      </div>
                    </div>
                  </div>
                  <Badge className={`${getCategoryColor(channel.category)} text-xs flex-shrink-0`}>
                    {channel.category}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-3 sm:space-y-4 flex-1 flex flex-col pt-0">
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed line-clamp-3 flex-1">
                  {channel.description}
                </p>

                <div className="space-y-2">
                  <h4 className="text-xs sm:text-sm font-semibold text-white">Especialidades:</h4>
                  <div className="flex flex-wrap gap-1">
                    {channel.specialties.slice(0, 3).map((specialty) => (
                      <Badge key={specialty} variant="secondary" className="text-xs px-2 py-1">
                        {specialty}
                      </Badge>
                    ))}
                    {channel.specialties.length > 3 && (
                      <Badge variant="secondary" className="text-xs px-2 py-1">
                        +{channel.specialties.length - 3}
                      </Badge>
                    )}
                  </div>
                </div>

                <Button
                  asChild
                  className="w-full btn-animate bg-primary hover:bg-primary/90 text-xs sm:text-sm mt-auto"
                  size="sm"
                >
                  <a
                    href={channel.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2"
                  >
                    <span>Acessar Canal</span>
                    <ExternalLink className="h-3 w-3 sm:h-4 sm:w-4" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Footer Info */}
        <div className="text-center space-y-4 pt-6 sm:pt-8 border-t border-border px-4">
          <h3 className="text-lg sm:text-xl font-semibold text-white">Dica de Estudo</h3>
          <p className="text-sm sm:text-base text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Combine diferentes canais para uma preparação completa. Assista às aulas teóricas, resolva exercícios e
            mantenha-se atualizado com os temas mais cobrados no ENEM.
          </p>
        </div>
      </div>
    </div>
  )
}
