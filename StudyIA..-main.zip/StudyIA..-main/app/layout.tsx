import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Navbar } from "@/components/navbar"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "Study IA - Seu Professor Particular de IA",
  description:
    "Plataforma educacional com IA para preparação do ENEM. Chat interativo, correção de redação e simulados personalizados.",
  generator: "v0.app",
  icons: {
    icon: "/favicon.ico",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" className={`${inter.variable} antialiased`}>
      <body className="min-h-screen bg-background font-sans">
        <Navbar />
        <main>{children}</main>
        <Toaster />
      </body>
    </html>
  )
}
