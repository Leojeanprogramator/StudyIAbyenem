import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Star, Users, Clock } from "lucide-react"

export default function SitesSimuladosPage() {
  const simuladoSites = [
    {
      name: "Resposta Certa",
      description:
        "Plataforma completa com simulados ENEM organizados por disciplina e ano. Interface moderna e questões atualizadas.",
      url: "https://respostacerta.com/",
      rating: 4.9,
      users: "1.8M+",
      features: ["Simulados por disciplina", "Questões atualizadas", "Interface moderna", "Análise de desempenho"],
    },
    {
      name: "Estude Prisma",
      description:
        "Banco de questões ENEM com filtros avançados e simulados personalizados. Ideal para prática direcionada.",
      url: "https://estudeprisma.com/questoes/s/enem/i",
      rating: 4.8,
      users: "950K+",
      features: ["Filtros avançados", "Simulados personalizados", "Banco extenso", "Prática direcionada"],
    },
    {
      name: "Descomplica",
      description:
        "Simulados antigos desde 2018 incríveis para praticar. Plataforma completa com questões organizadas por ano e área.",
      url: "https://simulado.descomplica.com.br/",
      rating: 4.9,
      users: "2.5M+",
      features: ["Simulados desde 2018", "Questões por área", "Correção detalhada", "Ranking nacional"],
    },
    {
      name: "Brasil Escola",
      description:
        "Simulados gratuitos do ENEM com questões de anos anteriores e gabarito comentado. Acesso completo aos simulados oficiais.",
      url: "https://vestibular.brasilescola.uol.com.br/enem/simulado",
      rating: 4.8,
      users: "1.2M+",
      features: ["Totalmente gratuito", "Questões oficiais", "Gabarito comentado", "Interface moderna"],
    },
  ]

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-8 sm:mb-12 animate-fade-in">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance leading-tight">
            Sites de <span className="text-primary">Simulados ENEM</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 text-pretty max-w-4xl mx-auto px-4">
            Acesse os melhores sites de simulados ENEM organizados em um só lugar. Pratique com questões oficiais e
            prepare-se de forma estratégica.
          </p>
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 sm:p-6 max-w-3xl mx-auto hover-glow">
            <p className="text-sm sm:text-base text-foreground leading-relaxed">
              <strong>DICA IMPORTANTE:</strong> Faça pelo menos 2-3 simulados por semana e analise seus erros. Varie
              entre simulados completos e por disciplina para melhor preparação.
            </p>
          </div>
        </div>

        {/* Sites Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-8 sm:mb-12">
          {simuladoSites.map((site, index) => (
            <Card
              key={index}
              className="bg-card border-border hover-lift animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-2">
                  <CardTitle className="text-xl sm:text-2xl font-bold text-foreground">{site.name}</CardTitle>
                  <div className="flex items-center space-x-1 text-yellow-500">
                    <Star className="h-4 w-4 sm:h-5 sm:w-5 fill-current" />
                    <span className="text-sm sm:text-base font-medium text-foreground">{site.rating}</span>
                  </div>
                </div>
                <CardDescription className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                  {site.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4 sm:space-y-6">
                {/* Stats */}
                <div className="flex items-center justify-between text-sm sm:text-base">
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <Users className="h-4 w-4 sm:h-5 sm:w-5" />
                    <span>{site.users} usuários</span>
                  </div>
                  <div className="flex items-center space-x-2 text-primary">
                    <Clock className="h-4 w-4 sm:h-5 sm:w-5" />
                    <span>Acesso imediato</span>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-3">
                  <h4 className="text-sm sm:text-base font-semibold text-foreground">Principais recursos:</h4>
                  <ul className="space-y-2">
                    {site.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-sm sm:text-base text-muted-foreground flex items-center">
                        <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-primary rounded-full mr-3 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Access Button */}
                <Button
                  asChild
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground btn-animate text-sm sm:text-base py-2 sm:py-3"
                >
                  <a
                    href={site.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center space-x-2"
                  >
                    <span>Acessar Site</span>
                    <ExternalLink className="h-4 w-4 sm:h-5 sm:w-5" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom Tips */}
        <div className="bg-card border border-border rounded-lg p-4 sm:p-6 lg:p-8 hover-lift animate-slide-in">
          <h3 className="text-xl sm:text-2xl font-bold text-foreground mb-4 sm:mb-6">
            Dicas para Aproveitar os Simulados
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            <div>
              <h4 className="text-lg sm:text-xl font-semibold text-primary mb-3 sm:mb-4">Estratégia de Estudo</h4>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    Faça simulados em horários similares ao ENEM (13h30 às 19h)
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    Alterne entre simulados completos e por disciplina
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    Analise sempre os erros e refaça questões similares
                  </span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg sm:text-xl font-semibold text-primary mb-3 sm:mb-4">Frequência Ideal</h4>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    2-3 simulados por semana para manter o ritmo
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    1 simulado completo por semana nos últimos 2 meses
                  </span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-2 flex-shrink-0" />
                  <span className="text-sm sm:text-base leading-relaxed">
                    Foque nas disciplinas com maior dificuldade
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
