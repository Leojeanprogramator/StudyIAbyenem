import { RedacaoAnalyzer } from "@/components/redacao-analyzer"

export default function RedacaoPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <RedacaoAnalyzer />
        </div>
      </div>
    </div>
  )
}
