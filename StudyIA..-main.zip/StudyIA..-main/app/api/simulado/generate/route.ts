import { type NextRequest, NextResponse } from "next/server"

const API_KEY =
  process.env.GENERATIVE_API_KEY || "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"
const MODEL = process.env.GENERATIVE_MODEL || "openai/gpt-4o-mini"
const API_URL = process.env.API_URL || "https://openrouter.ai/api/v1/chat/completions"

export async function POST(request: NextRequest) {
  try {
    const { materia, numQuestions, difficulty } = await request.json()

    if (!materia || !numQuestions || !difficulty) {
      return NextResponse.json({ error: "Parâmetros obrigatórios: materia, numQuestions, difficulty" }, { status: 400 })
    }

    console.log("[v0] Gerando simulado:", { materia, numQuestions, difficulty })

    const prompt = `Gere ${numQuestions} questões de múltipla escolha sobre ${materia} no padrão ENEM, nível ${difficulty}.

Retorne APENAS um JSON válido com esta estrutura:
{
  "questions": [
    {
      "id": 1,
      "question": "enunciado da questão com contexto",
      "alternatives": ["alternativa A", "alternativa B", "alternativa C", "alternativa D", "alternativa E"],
      "answer": "A",
      "explanation": "explicação detalhada da resposta correta"
    }
  ]
}

Requisitos importantes:
- Questões no estilo ENEM com contexto e situação-problema real
- 5 alternativas (A, B, C, D, E) para cada questão
- Nível de dificuldade: ${difficulty}
- Explicações claras e educativas
- Conteúdo adequado ao ${materia === "misto" ? "ENEM geral (todas as áreas)" : materia}
- Use dados reais, gráficos, textos de apoio quando apropriado
- Questões interdisciplinares quando possível`

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
        "X-Title": "ENEM AI - Gerador de Simulados",
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {
            role: "system",
            content:
              "Você é um especialista em criar questões do ENEM. Crie questões desafiadoras, contextualizadas e educativas seguindo o padrão oficial do exame.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 4000,
        stream: false,
      }),
    })

    console.log("[v0] Status da resposta simulado:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Erro da API simulado:", errorText)
      throw new Error(`API Error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    const aiResponse = data.choices?.[0]?.message?.content || ""

    console.log("[v0] Resposta do simulado recebida:", !!aiResponse)

    try {
      const result = JSON.parse(aiResponse)
      return NextResponse.json(result)
    } catch (parseError) {
      console.error("[v0] Erro ao fazer parse da resposta da IA:", parseError)
      // Retorna questões mock em caso de erro
      const fallbackQuestions = Array.from({ length: numQuestions }, (_, i) => ({
        id: i + 1,
        question: `Questão ${i + 1} sobre ${materia} (${difficulty}): Qual conceito está correto?`,
        alternatives: [
          "Primeira opção de resposta",
          "Segunda opção de resposta",
          "Terceira opção de resposta",
          "Quarta opção de resposta",
          "Quinta opção de resposta",
        ],
        answer: "A",
        explanation: "Explicação da resposta correta.",
      }))

      return NextResponse.json({ questions: fallbackQuestions })
    }
  } catch (error) {
    console.error("[v0] Erro na API de simulado:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}
