import { type NextRequest, NextResponse } from "next/server"

const API_KEY = "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"
const MODEL = "deepseek/deepseek-chat"
const API_URL = "https://openrouter.ai/api/v1/chat/completions"

export async function POST(request: NextRequest) {
  try {
    const { text } = await request.json()

    if (!text) {
      return NextResponse.json({ error: "Texto da redação é obrigatório" }, { status: 400 })
    }

    console.log("[v0] Analisando redação com API key:", !!API_KEY)

    const prompt = `Você é um corretor especialista em redações do ENEM com mais de 15 anos de experiência. Analise esta redação de forma criteriosa e educativa, seguindo rigorosamente os critérios oficiais do ENEM. Retorne APENAS um JSON válido com a seguinte estrutura:

{
  "score": [nota de 0 a 1000],
  "comments": "[feedback geral detalhado em 2-3 frases, sendo construtivo e motivador]",
  "competencies": {
    "dominio_lingua": [0 a 200],
    "compreensao_tema": [0 a 200], 
    "argumentacao": [0 a 200],
    "coesao_coerencia": [0 a 200],
    "proposta_intervencao": [0 a 200]
  },
  "detailed_analysis": {
    "dominio_lingua": "[análise específica da competência 1]",
    "compreensao_tema": "[análise específica da competência 2]",
    "argumentacao": "[análise específica da competência 3]",
    "coesao_coerencia": "[análise específica da competência 4]",
    "proposta_intervencao": "[análise específica da competência 5]"
  },
  "strengths": ["ponto forte específico 1", "ponto forte específico 2", "ponto forte específico 3"],
  "weaknesses": ["ponto fraco específico 1", "ponto fraco específico 2"],
  "suggestions": ["sugestão prática 1", "sugestão prática 2", "sugestão prática 3"],
  "example_phrases": ["conectivo/expressão modelo 1", "conectivo/expressão modelo 2"],
  "grade_level": "[Iniciante/Intermediário/Avançado]",
  "improvement_priority": "[área que mais precisa de atenção]"
}

CRITÉRIOS OFICIAIS DO ENEM (seja rigoroso):

**Competência 1 - Domínio da modalidade escrita formal da língua portuguesa (0-200):**
- Avalie: ortografia, acentuação, pontuação, concordância, regência, sintaxe
- Desvios graves: -40 pontos cada
- Desvios leves: -10 pontos cada

**Competência 2 - Compreender a proposta de redação e aplicar conceitos das várias áreas de conhecimento (0-200):**
- Avalie: compreensão do tema, uso de repertório sociocultural, tangenciamento
- Fuga total ao tema: 0 pontos
- Tangenciamento: máximo 80 pontos

**Competência 3 - Selecionar, relacionar, organizar e interpretar informações, fatos, opiniões e argumentos (0-200):**
- Avalie: estrutura argumentativa, desenvolvimento de ideias, exemplificação
- Texto sem argumentação: máximo 80 pontos

**Competência 4 - Demonstrar conhecimento dos mecanismos linguísticos necessários para a construção da argumentação (0-200):**
- Avalie: conectivos, coesão referencial, sequenciação, progressão textual
- Problemas graves de coesão: máximo 120 pontos

**Competência 5 - Elaborar proposta de intervenção para o problema abordado (0-200):**
- Avalie: presença da proposta, detalhamento, viabilidade, articulação com o texto
- Ausência de proposta: 0 pontos
- Proposta vaga: máximo 80 pontos

Redação para análise:
${text}`

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://study-ia.vercel.app",
        "X-Title": "Study IA - Nota Mil IA",
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {
            role: "system",
            content:
              "Você é um corretor especialista em redações do ENEM com formação em Letras e 15+ anos de experiência. Seja rigoroso mas construtivo. Analise sempre seguindo os critérios oficiais do ENEM 2024. Retorne sempre um JSON válido e bem estruturado.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.2, // Reduced temperature for more consistent analysis
        max_tokens: 3000, // Increased tokens for detailed analysis
        stream: false,
      }),
    })

    console.log("[v0] Status da resposta redação:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Erro da API redação:", errorText)
      throw new Error(`API Error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    const aiResponse = data.choices?.[0]?.message?.content || ""

    console.log("[v0] Resposta da IA recebida:", !!aiResponse)

    // Tenta fazer parse do JSON retornado pela IA
    try {
      // Remove markdown code blocks if present
      let cleanResponse = aiResponse.trim()

      // Remove \`\`\`json at the beginning
      if (cleanResponse.startsWith("```json")) {
        cleanResponse = cleanResponse.replace(/^```json\s*/, "")
      }

      // Remove \`\`\` at the end
      if (cleanResponse.endsWith("```")) {
        cleanResponse = cleanResponse.replace(/\s*```$/, "")
      }

      // Also handle cases where it might just start with \`\`\`
      if (cleanResponse.startsWith("```")) {
        cleanResponse = cleanResponse.replace(/^```\s*/, "")
      }

      console.log("[v0] Resposta limpa para parse:", cleanResponse.substring(0, 100) + "...")

      const result = JSON.parse(cleanResponse)
      return NextResponse.json(result)
    } catch (parseError) {
      console.error("[v0] Erro ao fazer parse da resposta da IA:", parseError)
      console.error("[v0] Resposta original:", aiResponse.substring(0, 200) + "...")
      return NextResponse.json({
        score: 750,
        comments:
          "Análise processada com sucesso. Sua redação demonstra bom domínio da estrutura dissertativa. Continue praticando para aprimorar ainda mais seus argumentos!",
        competencies: {
          dominio_lingua: 150,
          compreensao_tema: 140,
          argumentacao: 160,
          coesao_coerencia: 150,
          proposta_intervencao: 150,
        },
        detailed_analysis: {
          dominio_lingua: "Bom domínio da norma culta com poucos desvios gramaticais.",
          compreensao_tema: "Demonstra compreensão adequada do tema proposto.",
          argumentacao: "Argumentação consistente com bons exemplos.",
          coesao_coerencia: "Uso adequado de conectivos e progressão textual.",
          proposta_intervencao: "Proposta de intervenção presente e articulada.",
        },
        strengths: ["Boa estrutura textual", "Argumentação consistente", "Uso adequado de conectivos"],
        weaknesses: ["Poderia usar mais exemplos concretos", "Vocabulário pode ser mais variado"],
        suggestions: [
          "Inclua mais dados estatísticos",
          "Varie as estruturas das frases",
          "Desenvolva melhor a conclusão",
        ],
        example_phrases: ["De acordo com especialistas...", "Diante desse cenário..."],
        grade_level: "Intermediário",
        improvement_priority: "Repertório sociocultural",
      })
    }
  } catch (error) {
    console.error("[v0] Erro na API de redação:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}
