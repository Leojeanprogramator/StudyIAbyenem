import { type NextRequest, NextResponse } from "next/server"

const API_KEY =
  process.env.GENERATIVE_API_KEY || "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"
const MODEL = process.env.GENERATIVE_MODEL || "deepseek/deepseek-chat"
const API_URL = process.env.API_URL || "https://openrouter.ai/api/v1/chat/completions"

interface Message {
  role: "user" | "assistant" | "system"
  content: string
}

export async function POST(request: NextRequest) {
  try {
    const { prompt, context = [], mode = "chat" } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt é obrigatório" }, { status: 400 })
    }

    console.log("[v0] API Key disponível:", !!API_KEY)
    console.log("[v0] Modelo:", MODEL)
    console.log("[v0] URL da API:", API_URL)

    const messages: Message[] = [
      {
        role: "system",
        content: `Você é uma Inteligência Artificial especializada em ENEM e deve atuar como um avaliador, professor e gerador de simulados dentro de um site educacional. 

REGRAS DE FORMATAÇÃO IMPORTANTES:
- Use MAIÚSCULAS apenas para destacar PALAVRAS-CHAVE IMPORTANTES, PERGUNTAS DIRETAS e PONTOS DE AÇÃO
- NUNCA use símbolos como ** ou ## para dar destaque
- Use quebras de linha para organizar suas respostas
- Mantenha clareza e objetividade
- NUNCA perca a linha de raciocínio, mesmo se o usuário mudar de assunto

EXEMPLOS DE USO CORRETO DE MAIÚSCULAS:
- "PARA COMEÇAR, me conte: QUAL ÁREA você mais gosta de estudar?"
- "IMPORTANTE: essa questão cobra conhecimento de..."
- "DICA FUNDAMENTAL: sempre leia o enunciado..."
- "VAMOS PRATICAR: resolva este exercício..."

OBJETIVOS PRINCIPAIS:
1. Chat interativo inicial — quando o usuário abrir o site, você deve dar boas-vindas e fazer perguntas rápidas sobre o ENEM
2. Professor IA — quando perguntado sobre matérias, explique com clareza e exemplos práticos do ENEM
3. Use linguagem de professor particular, didática e amigável

ESTILO DE RESPOSTA:
- Respostas sempre ORGANIZADAS com QUEBRAS DE LINHA
- Se o usuário retomar um tema anterior, continue exatamente de onde parou
- Use texto didático e amigável no chat
- Mantenha as respostas focadas e úteis para estudantes do ENEM
- Use maiúsculas ESTRATEGICAMENTE para destacar apenas o essencial

Responda sempre em português brasileiro.`,
      },
      ...context.map((msg: any) => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      })),
      {
        role: "user",
        content: prompt,
      },
    ]

    console.log("[v0] Enviando requisição para OpenRouter...")

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
        "X-Title": "ENEM AI - Plataforma Educacional",
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        temperature: 0.7,
        max_tokens: 1500,
        stream: false,
      }),
    })

    console.log("[v0] Status da resposta:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Erro da API:", errorText)
      throw new Error(`API Error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    console.log("[v0] Resposta recebida:", !!data.choices?.[0]?.message?.content)

    const aiResponse = data.choices?.[0]?.message?.content || "Desculpe, não consegui processar sua solicitação."

    return NextResponse.json({ response: aiResponse })
  } catch (error) {
    console.error("[v0] Erro na API de geração:", error)
    return NextResponse.json(
      {
        error: "Erro interno do servidor",
        details: error instanceof Error ? error.message : "Erro desconhecido",
      },
      { status: 500 },
    )
  }
}
