import { BancoQuestoes } from "@/components/banco-questoes"

export default function QuestoesPage() {
  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Banco de Questões</h1>
            <p className="text-lg text-muted-foreground">
              Explore questões organizadas por matéria e nível de dificuldade
            </p>
          </div>

          <BancoQuestoes />
        </div>
      </div>
    </div>
  )
}
