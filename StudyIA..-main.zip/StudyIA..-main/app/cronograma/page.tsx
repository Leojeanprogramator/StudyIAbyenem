"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calculator, BookOpen, Atom, Users, PenTool, Calendar, Target, Clock, ExternalLink } from "lucide-react"

export default function CronogramaPage() {
  const [selectedFilter, setSelectedFilter] = useState("todos")

  const disciplinas = [
    {
      id: "matematica",
      name: "Matemática",
      icon: Calculator,
      color: "bg-blue-500",
      topics: [
        { name: "Funções", priority: "alta", weeks: 3 },
        { name: "Estatística e Probabilidade", priority: "alta", weeks: 2 },
        { name: "Geometria Plana", priority: "alta", weeks: 2 },
        { name: "Razão e Proporção", priority: "media", weeks: 2 },
        { name: "Porcentagem", priority: "alta", weeks: 1 },
        { name: "Análise Combinatória", priority: "media", weeks: 2 },
      ],
    },
    {
      id: "linguagens",
      name: "Linguagens",
      icon: BookOpen,
      color: "bg-green-500",
      topics: [
        { name: "Interpretação de Texto", priority: "alta", weeks: 4 },
        { name: "Figuras de Linguagem", priority: "alta", weeks: 2 },
        { name: "Gêneros Textuais", priority: "alta", weeks: 2 },
        { name: "Literatura Brasileira", priority: "media", weeks: 3 },
        { name: "Gramática", priority: "media", weeks: 2 },
        { name: "Inglês/Espanhol", priority: "media", weeks: 2 },
      ],
    },
    {
      id: "natureza",
      name: "Ciências da Natureza",
      icon: Atom,
      color: "bg-purple-500",
      topics: [
        { name: "Ecologia", priority: "alta", weeks: 2 },
        { name: "Energia e Suas Transformações", priority: "alta", weeks: 2 },
        { name: "Eletroquímica", priority: "alta", weeks: 2 },
        { name: "Genética", priority: "media", weeks: 2 },
        { name: "Mecânica", priority: "media", weeks: 2 },
        { name: "Química Orgânica", priority: "media", weeks: 3 },
      ],
    },
    {
      id: "humanas",
      name: "Ciências Humanas",
      icon: Users,
      color: "bg-orange-500",
      topics: [
        { name: "Movimentos Sociais", priority: "alta", weeks: 2 },
        { name: "Ditadura Militar", priority: "alta", weeks: 2 },
        { name: "Cidadania e Democracia", priority: "alta", weeks: 2 },
        { name: "Geopolítica", priority: "media", weeks: 2 },
        { name: "Urbanização", priority: "media", weeks: 2 },
        { name: "Globalização", priority: "media", weeks: 2 },
      ],
    },
    {
      id: "redacao",
      name: "Redação",
      icon: PenTool,
      color: "bg-red-500",
      topics: [
        { name: "Estrutura Dissertativa", priority: "alta", weeks: 2 },
        { name: "Argumentação", priority: "alta", weeks: 2 },
        { name: "Proposta de Intervenção", priority: "alta", weeks: 2 },
        { name: "Coesão e Coerência", priority: "alta", weeks: 2 },
        { name: "Repertório Sociocultural", priority: "media", weeks: 2 },
        { name: "Temas Atuais", priority: "alta", weeks: 1 },
      ],
    },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "alta":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "media":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const filteredDisciplinas =
    selectedFilter === "todos" ? disciplinas : disciplinas.filter((d) => d.id === selectedFilter)

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-8 sm:mb-12 animate-fade-in">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance leading-tight">
            <span className="text-primary">Cronograma</span> Estratégico ENEM
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-6 text-pretty max-w-4xl mx-auto px-4">
            Use uma ferramenta avançada para o seu objetivo. Foque no que mais cai e maximize seus resultados com um
            plano estratégico personalizado.
          </p>

          {/* Strategy Alert */}
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 sm:p-6 max-w-4xl mx-auto mb-6 sm:mb-8 hover-glow">
            <div className="flex items-start space-x-3">
              <Target className="h-5 w-5 sm:h-6 sm:w-6 text-primary flex-shrink-0 mt-1" />
              <div className="text-left">
                <h3 className="text-base sm:text-lg font-semibold text-foreground mb-2">Estratégia Inteligente</h3>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Este cronograma foca nos <strong>assuntos que mais caem no ENEM</strong>. Estudar estrategicamente é
                  mais eficiente que tentar cobrir todo o conteúdo do ensino médio. Priorize os tópicos marcados como
                  "Alta Prioridade" para maximizar sua pontuação.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-4 sm:p-6 max-w-4xl mx-auto hover-lift">
            <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4">
              <div className="text-center sm:text-left">
                <h3 className="text-lg sm:text-xl font-bold text-foreground mb-2">
                  Cronograma de Estudos Brasil Escola
                </h3>
                <p className="text-sm sm:text-base text-muted-foreground">
                  Acesse o cronograma completo e detalhado do Brasil Escola para organizar seus estudos de forma
                  eficiente.
                </p>
              </div>
              <Button
                asChild
                className="bg-primary hover:bg-primary/90 text-primary-foreground btn-animate flex-shrink-0"
              >
                <a
                  href="https://vestibular.brasilescola.uol.com.br/enem/cronograma-estudos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2"
                >
                  <span>Acessar Cronograma</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <Tabs value={selectedFilter} onValueChange={setSelectedFilter} className="mb-6 sm:mb-8">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 bg-card h-auto p-1">
            <TabsTrigger value="todos" className="text-xs sm:text-sm py-2">
              Todas
            </TabsTrigger>
            <TabsTrigger value="matematica" className="text-xs sm:text-sm py-2">
              Matemática
            </TabsTrigger>
            <TabsTrigger value="linguagens" className="text-xs sm:text-sm py-2">
              Linguagens
            </TabsTrigger>
            <TabsTrigger value="natureza" className="text-xs sm:text-sm py-2">
              Natureza
            </TabsTrigger>
            <TabsTrigger value="humanas" className="text-xs sm:text-sm py-2">
              Humanas
            </TabsTrigger>
            <TabsTrigger value="redacao" className="text-xs sm:text-sm py-2">
              Redação
            </TabsTrigger>
          </TabsList>

          <TabsContent value={selectedFilter} className="mt-4 sm:mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {filteredDisciplinas.map((disciplina, index) => {
                const Icon = disciplina.icon
                const totalWeeks = disciplina.topics.reduce((sum, topic) => sum + topic.weeks, 0)

                return (
                  <Card
                    key={disciplina.id}
                    className="bg-card border-border hover-lift animate-fade-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <CardHeader className="pb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 sm:p-3 rounded-lg ${disciplina.color}`}>
                          <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-lg sm:text-xl text-foreground">{disciplina.name}</CardTitle>
                          <CardDescription className="flex items-center space-x-2 text-sm sm:text-base">
                            <Clock className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span>{totalWeeks} semanas de estudo</span>
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="space-y-3">
                        {disciplina.topics.map((topic, topicIndex) => (
                          <div
                            key={topicIndex}
                            className="flex items-center justify-between p-3 bg-background/50 rounded-lg border border-border/50 hover-glow animate-slide-in"
                            style={{ animationDelay: `${topicIndex * 0.05}s` }}
                          >
                            <div className="flex-1 min-w-0">
                              <h4 className="font-medium text-foreground text-sm sm:text-base truncate">
                                {topic.name}
                              </h4>
                              <p className="text-xs sm:text-sm text-muted-foreground">
                                {topic.weeks} semana{topic.weeks > 1 ? "s" : ""} de estudo
                              </p>
                            </div>
                            <Badge className={`${getPriorityColor(topic.priority)} text-xs flex-shrink-0 ml-2`}>
                              {topic.priority === "alta" ? "Alta" : "Média"}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
        </Tabs>

        {/* Generate Custom Schedule */}
        <div className="mt-12 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-lg p-8 text-center">
          <Calendar className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-foreground mb-4">Gerar Meu Cronograma Personalizado</h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Crie um cronograma personalizado baseado no tempo que você tem até a prova do ENEM. Nossa IA organizará os
            estudos de forma otimizada para seu perfil.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Gerar Cronograma Personalizado
          </Button>
          <p className="text-sm text-muted-foreground mt-3">
            Funcionalidade em desenvolvimento - Em breve com integração de IA
          </p>
        </div>

        {/* Study Tips */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          <Card className="bg-card border-border hover-lift">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl text-foreground flex items-center space-x-2">
                <Target className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                <span>Como Usar Este Cronograma</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Comece pelos tópicos de <strong>Alta Prioridade</strong>
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Dedique mais tempo às suas disciplinas mais fracas
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Faça revisões semanais dos tópicos estudados
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Intercale teoria com exercícios práticos
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover-lift">
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl text-foreground flex items-center space-x-2">
                <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                <span>Distribuição de Tempo</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  <strong>60%</strong> do tempo em tópicos de Alta Prioridade
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  <strong>30%</strong> do tempo em tópicos de Média Prioridade
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  <strong>10%</strong> do tempo para revisão geral
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  Mantenha <strong>2-3 horas diárias</strong> de estudo focado
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
